package com.medflow.ops

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.ExitToApp
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.medflow.ops.model.MedFlowScreen
import com.medflow.ops.state.MedFlowViewModel
import com.medflow.ops.theme.MedCardSurface
import com.medflow.ops.theme.MedFlowOpsTheme
import com.medflow.ops.theme.MedSlateNavy
import com.medflow.ops.theme.MedSurfaceCanvas
import com.medflow.ops.ui.screens.DashboardScreen
import com.medflow.ops.ui.screens.OperationsScreen
import com.medflow.ops.ui.screens.ReportsScreen
import com.medflow.ops.ui.screens.WelcomeScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MedFlowOpsTheme {
                MedFlowApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedFlowApp(viewModel: MedFlowViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    if (state.currentScreen == MedFlowScreen.WELCOME) {
        WelcomeScreen(
            selectedRole = state.selectedRole,
            onSelectRole = viewModel::selectRole,
            onEnterWorkspace = { viewModel.navigateTo(MedFlowScreen.DASHBOARD) }
        )
        return
    }

    Scaffold(
        containerColor = MedSurfaceCanvas,
        topBar = {
            TopAppBar(
                title = { Text("MedFlow Ops", color = MedSlateNavy) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MedCardSurface),
                actions = {
                    IconButton(onClick = { viewModel.navigateTo(MedFlowScreen.WELCOME) }) {
                        Icon(
                            imageVector = Icons.Outlined.ExitToApp,
                            contentDescription = "Switch Role",
                            tint = MedSlateNavy
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MedCardSurface) {
                NavigationBarItem(
                    selected = state.currentScreen == MedFlowScreen.DASHBOARD,
                    onClick = { viewModel.navigateTo(MedFlowScreen.DASHBOARD) },
                    icon = { Icon(Icons.Outlined.Dashboard, contentDescription = null) },
                    label = { Text("Dashboard") }
                )
                NavigationBarItem(
                    selected = state.currentScreen == MedFlowScreen.OPERATIONS,
                    onClick = { viewModel.navigateTo(MedFlowScreen.OPERATIONS) },
                    icon = { Icon(Icons.Outlined.Assignment, contentDescription = null) },
                    label = { Text("Operations") }
                )
                NavigationBarItem(
                    selected = state.currentScreen == MedFlowScreen.REPORTS,
                    onClick = { viewModel.navigateTo(MedFlowScreen.REPORTS) },
                    icon = { Icon(Icons.Outlined.Assessment, contentDescription = null) },
                    label = { Text("Reports") }
                )
            }
        }
    ) { innerPadding: PaddingValues ->
        when (state.currentScreen) {
            MedFlowScreen.WELCOME -> Unit
            MedFlowScreen.DASHBOARD -> DashboardScreen(
                role = state.selectedRole,
                kpis = state.kpis,
                alerts = state.alerts,
                onNavigate = viewModel::navigateTo,
                contentPadding = innerPadding
            )
            MedFlowScreen.OPERATIONS -> OperationsScreen(
                cases = state.cases,
                plans = state.generatedPlans,
                checkedStepIds = state.checkedStepIds,
                focusedCaseId = state.focusedCaseId,
                onAddCase = viewModel::addCase,
                onCycleStatus = viewModel::cycleCaseStatus,
                onGeneratePlan = viewModel::generateSopPlan,
                onToggleStep = viewModel::toggleStepChecked,
                contentPadding = innerPadding
            )
            MedFlowScreen.REPORTS -> ReportsScreen(
                role = state.selectedRole,
                cases = state.cases,
                contentPadding = innerPadding
            )
        }
    }
}
