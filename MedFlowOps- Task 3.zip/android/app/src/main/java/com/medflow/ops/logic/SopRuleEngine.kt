package com.medflow.ops.logic

import com.medflow.ops.model.AlertSeverity
import com.medflow.ops.model.CaseStatus
import com.medflow.ops.model.IssueType
import com.medflow.ops.model.OperationalRecommendation
import com.medflow.ops.model.RecommendationCategory
import com.medflow.ops.model.ServiceCase
import com.medflow.ops.model.SessionMetrics
import com.medflow.ops.model.SopActionPlan
import com.medflow.ops.model.SopStep
import com.medflow.ops.model.UserRole
import kotlin.math.max
import kotlin.math.roundToInt

object SopRuleEngine {

    fun classifySeverity(issueType: IssueType, waitTimeMinutes: Int): AlertSeverity {
        return when (issueType) {
            IssueType.DISCHARGE_TAT -> when {
                waitTimeMinutes >= 120 -> AlertSeverity.CRITICAL
                waitTimeMinutes >= 90 -> AlertSeverity.HIGH
                else -> AlertSeverity.MODERATE
            }
            else -> when {
                waitTimeMinutes >= 40 -> AlertSeverity.CRITICAL
                waitTimeMinutes >= 25 -> AlertSeverity.HIGH
                else -> AlertSeverity.MODERATE
            }
        }
    }

    fun generateSopActionPlan(serviceCase: ServiceCase): SopActionPlan {
        val severity = classifySeverity(serviceCase.issueType, serviceCase.waitTimeMinutes)
        val ratio = when (severity) {
            AlertSeverity.CRITICAL -> 0.42
            AlertSeverity.HIGH -> 0.35
            AlertSeverity.MODERATE -> 0.25
        }
        val savedMins = max(8, (serviceCase.waitTimeMinutes * ratio).roundToInt())

        return when (serviceCase.issueType) {
            IssueType.OPD_DELAY -> SopActionPlan(
                caseId = serviceCase.id,
                protocolCode = "SOP-OPD-04",
                title = "Fast-Track Queue Mitigation — ${serviceCase.departmentName}",
                projectedMinutesSaved = savedMins,
                steps = listOf(
                    SopStep(
                        "${serviceCase.id}-1", 1,
                        "Open fast-track vitals & triage counter at ${serviceCase.departmentName} for waits > 20 mins.",
                        "Front-Office Supervisor", 5
                    ),
                    SopStep(
                        "${serviceCase.id}-2", 2,
                        "Route routine prescription renewals to an express lane separate from new consults.",
                        "Clinic Nurse Coordinator", 10
                    ),
                    SopStep(
                        "${serviceCase.id}-3", 3,
                        "Update clinic queue display boards and notify waiting patients of revised ETAs.",
                        "Front-Office Desk", 5
                    ),
                    SopStep(
                        "${serviceCase.id}-4", 4,
                        "Re-audit queue with ${serviceCase.assignedOwner} after 20 minutes; assign float physician if needed.",
                        "Hospital Administrator", 20
                    )
                )
            )

            IssueType.DISCHARGE_TAT -> SopActionPlan(
                caseId = serviceCase.id,
                protocolCode = "SOP-DIS-02",
                title = "Accelerated Bed Turnaround — ${serviceCase.departmentName}",
                projectedMinutesSaved = savedMins,
                steps = listOf(
                    SopStep(
                        "${serviceCase.id}-1", 1,
                        "Trigger early pharmacy clearance flag for pending TTO medications in ${serviceCase.departmentName}.",
                        "Inpatient Pharmacy Lead", 10
                    ),
                    SopStep(
                        "${serviceCase.id}-2", 2,
                        "Run parallel billing pre-audit and TPA clearance prior to discharge counseling.",
                        "Billing & TPA Desk", 15
                    ),
                    SopStep(
                        "${serviceCase.id}-3", 3,
                        "Transfer clinically cleared patients to Discharge Lounge to free inpatient beds.",
                        "Nursing Lead", 15
                    ),
                    SopStep(
                        "${serviceCase.id}-4", 4,
                        "Dispatch housekeeping rapid-turn team and confirm bed status with ${serviceCase.assignedOwner}.",
                        "Bed Coordinator", 20
                    )
                )
            )

            IssueType.DIAGNOSTIC_DELAY -> SopActionPlan(
                caseId = serviceCase.id,
                protocolCode = "SOP-DX-07",
                title = "STAT Diagnostic Slot Rebalancing — ${serviceCase.departmentName}",
                projectedMinutesSaved = savedMins,
                steps = listOf(
                    SopStep(
                        "${serviceCase.id}-1", 1,
                        "Reserve next two modality slots in ${serviceCase.departmentName} for STAT inpatient orders.",
                        "Diagnostics Lead", 5
                    ),
                    SopStep(
                        "${serviceCase.id}-2", 2,
                        "Assign dedicated porter escort for prepped ward patients to prevent idle gaps.",
                        "Transport Desk", 10
                    ),
                    SopStep(
                        "${serviceCase.id}-3", 3,
                        "Re-sequence non-urgent outpatient bookings into afternoon buffer slots.",
                        "Front-Office Supervisor", 10
                    ),
                    SopStep(
                        "${serviceCase.id}-4", 4,
                        "Confirm wet-read upload in EMR and notify ${serviceCase.assignedOwner}.",
                        "Radiology Officer", 15
                    )
                )
            )

            IssueType.PATIENT_ESCALATION -> SopActionPlan(
                caseId = serviceCase.id,
                protocolCode = "SOP-ESC-01",
                title = "Service Recovery Protocol — ${serviceCase.departmentName}",
                projectedMinutesSaved = savedMins,
                steps = listOf(
                    SopStep(
                        "${serviceCase.id}-1", 1,
                        "Conduct immediate 3-minute acknowledgement at ${serviceCase.departmentName} with ${serviceCase.assignedOwner}.",
                        "Shift Supervisor", 3
                    ),
                    SopStep(
                        "${serviceCase.id}-2", 2,
                        "Verify clinical triage priority and provide time-stamped transfer ETA to patient/family.",
                        "Nursing Lead", 10
                    ),
                    SopStep(
                        "${serviceCase.id}-3", 3,
                        "Resolve blocking handoff (bed, specialist, or billing hold) via direct shift hotline.",
                        "Hospital Administrator", 15
                    ),
                    SopStep(
                        "${serviceCase.id}-4", 4,
                        "Record closure note and complete comfort check prior to resolving case.",
                        "Patient Relations", 15
                    )
                )
            )
        }
    }

    fun computeSessionMetrics(cases: List<ServiceCase>): SessionMetrics {
        val total = cases.size
        val resolved = cases.count { it.status == CaseStatus.RESOLVED }
        val avgDelay = if (total == 0) 0 else (cases.sumOf { it.waitTimeMinutes }.toDouble() / total).roundToInt()

        val timeSaved = cases.sumOf { item ->
            val planSaved = generateSopActionPlan(item).projectedMinutesSaved
            when (item.status) {
                CaseStatus.RESOLVED -> planSaved
                CaseStatus.IN_PROGRESS -> (planSaved * 0.5).roundToInt()
                CaseStatus.OPEN -> 0
            }
        }

        return SessionMetrics(
            totalCasesReviewed = total,
            resolvedCount = resolved,
            averageDelayMinutes = avgDelay,
            projectedTimeSavedMinutes = timeSaved
        )
    }

    fun buildRecommendations(cases: List<ServiceCase>, role: UserRole): List<OperationalRecommendation> {
        val opdCount = cases.count { it.issueType == IssueType.OPD_DELAY }
        val dischargeCount = cases.count { it.issueType == IssueType.DISCHARGE_TAT }
        val diagnosticCount = cases.count { it.issueType == IssueType.DIAGNOSTIC_DELAY }
        val unresolvedCount = cases.count { it.status != CaseStatus.RESOLVED }

        return listOf(
            OperationalRecommendation(
                id = "REC-1",
                category = RecommendationCategory.PATIENT_FLOW,
                title = "Deploy Fast-Track Triage Counter for Peak OPD Queues",
                rationale = "$opdCount OPD delay case(s) logged during current shift window.",
                actionItem = "Route prescription renewals to a 10-minute express counter when wait > 20 mins.",
                impactLabel = "Est. -12 to -18 mins OPD wait"
            ),
            OperationalRecommendation(
                id = "REC-2",
                category = RecommendationCategory.PATIENT_FLOW,
                title = "Standardize Ward Discharge Lounge Handoffs",
                rationale = "$dischargeCount discharge TAT delay(s) impacting inpatient bed availability.",
                actionItem = "Move cleared patients to Discharge Lounge 45 mins before final billing sign-off.",
                impactLabel = "Est. -30 mins bed turnover"
            ),
            OperationalRecommendation(
                id = "REC-3",
                category = RecommendationCategory.STAFF_ALLOCATION,
                title = "Reallocate Float Porter & Pharmacy Runner (${role.label})",
                rationale = "$unresolvedCount active bottleneck(s) plus $diagnosticCount diagnostic queue delay(s).",
                actionItem = "Assign 1 float nurse and 1 transport porter to Ward B & Radiology during 10:00–13:00 peak.",
                impactLabel = "Covers 100% STAT transfer SLAs"
            ),
            OperationalRecommendation(
                id = "REC-4",
                category = RecommendationCategory.SOP_COMPLIANCE,
                title = "Enforce T-2 Hour Pre-Discharge Pharmacy Trigger",
                rationale = "Shift SOP Audit Score is 88% against the 90% compliance benchmark.",
                actionItem = "Flag planned discharges in EMR by 09:30 AM for parallel TTO medication packing.",
                impactLabel = "Targets > 93% SOP compliance"
            )
        )
    }
}
