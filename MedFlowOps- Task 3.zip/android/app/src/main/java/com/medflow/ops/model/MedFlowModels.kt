package com.medflow.ops.model

enum class UserRole(val label: String) {
    HOSPITAL_ADMIN("Hospital Administrator"),
    NURSING_LEAD("Nursing Lead"),
    FRONT_OFFICE_SUPERVISOR("Front-Office Supervisor")
}

enum class MedFlowScreen(val label: String) {
    WELCOME("Welcome"),
    DASHBOARD("Dashboard"),
    OPERATIONS("Operations"),
    REPORTS("Reports")
}

enum class IssueType(val label: String) {
    OPD_DELAY("OPD Delay"),
    DISCHARGE_TAT("Discharge TAT"),
    DIAGNOSTIC_DELAY("Diagnostic Delay"),
    PATIENT_ESCALATION("Patient Escalation")
}

enum class CaseStatus(val label: String) {
    OPEN("Open"),
    IN_PROGRESS("In Progress"),
    RESOLVED("Resolved");

    fun next(): CaseStatus = when (this) {
        OPEN -> IN_PROGRESS
        IN_PROGRESS -> RESOLVED
        RESOLVED -> OPEN
    }
}

enum class AlertSeverity(val label: String) {
    CRITICAL("Critical"),
    HIGH("High"),
    MODERATE("Moderate")
}

enum class RecommendationCategory(val label: String) {
    PATIENT_FLOW("Patient Flow"),
    STAFF_ALLOCATION("Staff Allocation"),
    SOP_COMPLIANCE("SOP Compliance")
}

data class ShiftKpi(
    val id: String,
    val label: String,
    val value: String,
    val target: String,
    val statusLabel: String,
    val isAlertState: Boolean
)

data class BottleneckAlert(
    val id: String,
    val linkedCaseId: String,
    val department: String,
    val title: String,
    val summary: String,
    val severity: AlertSeverity,
    val delayMinutes: Int,
    val owner: String
)

data class ServiceCase(
    val id: String,
    val departmentName: String,
    val issueType: IssueType,
    val waitTimeMinutes: Int,
    val assignedOwner: String,
    val status: CaseStatus,
    val loggedAt: String
)

data class SopStep(
    val id: String,
    val stepNumber: Int,
    val action: String,
    val ownerRole: String,
    val slaMinutes: Int
)

data class SopActionPlan(
    val caseId: String,
    val protocolCode: String,
    val title: String,
    val projectedMinutesSaved: Int,
    val steps: List<SopStep>
)

data class SessionMetrics(
    val totalCasesReviewed: Int,
    val resolvedCount: Int,
    val averageDelayMinutes: Int,
    val projectedTimeSavedMinutes: Int
)

data class OperationalRecommendation(
    val id: String,
    val category: RecommendationCategory,
    val title: String,
    val rationale: String,
    val actionItem: String,
    val impactLabel: String
)
