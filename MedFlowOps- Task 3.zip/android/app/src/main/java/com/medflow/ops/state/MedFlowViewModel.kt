package com.medflow.ops.state

import androidx.lifecycle.ViewModel
import com.medflow.ops.logic.SopRuleEngine
import com.medflow.ops.model.AlertSeverity
import com.medflow.ops.model.BottleneckAlert
import com.medflow.ops.model.CaseStatus
import com.medflow.ops.model.IssueType
import com.medflow.ops.model.MedFlowScreen
import com.medflow.ops.model.ServiceCase
import com.medflow.ops.model.ShiftKpi
import com.medflow.ops.model.SopActionPlan
import com.medflow.ops.model.UserRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class MedFlowUiState(
    val selectedRole: UserRole = UserRole.HOSPITAL_ADMIN,
    val currentScreen: MedFlowScreen = MedFlowScreen.WELCOME,
    val kpis: List<ShiftKpi> = defaultKpis(),
    val alerts: List<BottleneckAlert> = defaultAlerts(),
    val cases: List<ServiceCase> = defaultCases(),
    val generatedPlans: Map<String, SopActionPlan> = emptyMap(),
    val checkedStepIds: Set<String> = emptySet(),
    val focusedCaseId: String? = null
)

class MedFlowViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(MedFlowUiState())
    val uiState: StateFlow<MedFlowUiState> = _uiState.asStateFlow()

    fun selectRole(role: UserRole) {
        _uiState.update { it.copy(selectedRole = role) }
    }

    fun navigateTo(screen: MedFlowScreen, focusCaseId: String? = null) {
        _uiState.update { it.copy(currentScreen = screen, focusedCaseId = focusCaseId) }
    }

    fun addCase(
        departmentName: String,
        issueType: IssueType,
        waitTimeMinutes: Int,
        assignedOwner: String
    ) {
        val nextNumber = 101 + _uiState.value.cases.size
        val newCase = ServiceCase(
            id = "CASE-$nextNumber",
            departmentName = departmentName.trim(),
            issueType = issueType,
            waitTimeMinutes = waitTimeMinutes,
            assignedOwner = assignedOwner.trim(),
            status = CaseStatus.OPEN,
            loggedAt = "Just now"
        )
        _uiState.update { state ->
            state.copy(cases = listOf(newCase) + state.cases)
        }
    }

    fun cycleCaseStatus(caseId: String) {
        _uiState.update { state ->
            val updated = state.cases.map { item ->
                if (item.id == caseId) item.copy(status = item.status.next()) else item
            }
            state.copy(cases = updated)
        }
    }

    fun generateSopPlan(serviceCase: ServiceCase) {
        val plan = SopRuleEngine.generateSopActionPlan(serviceCase)
        _uiState.update { state ->
            state.copy(generatedPlans = state.generatedPlans + (serviceCase.id to plan))
        }
    }

    fun toggleStepChecked(stepId: String) {
        _uiState.update { state ->
            val updated = if (stepId in state.checkedStepIds) {
                state.checkedStepIds - stepId
            } else {
                state.checkedStepIds + stepId
            }
            state.copy(checkedStepIds = updated)
        }
    }
}

private fun defaultKpis(): List<ShiftKpi> = listOf(
    ShiftKpi("kpi-1", "Avg OPD Wait Time", "28 mins", "Target: < 20 mins", "Above Target", true),
    ShiftKpi("kpi-2", "Discharge Turnaround (TAT)", "115 mins", "Target: < 90 mins", "Above Target", true),
    ShiftKpi("kpi-3", "Bed Occupancy Rate", "86%", "172 / 200 Beds", "Watch", false),
    ShiftKpi("kpi-4", "Shift SOP Audit Score", "88%", "Target: >= 90%", "Watch", false)
)

private fun defaultAlerts(): List<BottleneckAlert> = listOf(
    BottleneckAlert(
        "ALT-01", "CASE-101", "Cardiology OPD",
        "Cardiology OPD Queue Delay",
        "14 walk-in consultations creating 42-minute triage lag.",
        AlertSeverity.CRITICAL, 42, "Front-Office Sup. A. Nair"
    ),
    BottleneckAlert(
        "ALT-02", "CASE-102", "Ward B",
        "Ward B Discharge Pending Pharmacy Clearance",
        "3 confirmed discharges stalled at 135 mins awaiting TTO packs.",
        AlertSeverity.CRITICAL, 135, "Nurse Lead K. Patel"
    ),
    BottleneckAlert(
        "ALT-03", "CASE-103", "Radiology",
        "Radiology Stat TAT Alert",
        "Inpatient STAT CT orders exceeding 45-minute threshold.",
        AlertSeverity.HIGH, 54, "Tech Coord. M. Verma"
    )
)

private fun defaultCases(): List<ServiceCase> = listOf(
    ServiceCase("CASE-101", "Cardiology OPD", IssueType.OPD_DELAY, 42, "Front-Office Sup. A. Nair", CaseStatus.OPEN, "09:15 AM"),
    ServiceCase("CASE-102", "Ward B (General Medicine)", IssueType.DISCHARGE_TAT, 135, "Nurse Lead K. Patel", CaseStatus.IN_PROGRESS, "09:40 AM"),
    ServiceCase("CASE-103", "Radiology CT Wing", IssueType.DIAGNOSTIC_DELAY, 54, "Tech Coord. M. Verma", CaseStatus.OPEN, "10:05 AM"),
    ServiceCase("CASE-104", "Emergency Intake Desk", IssueType.PATIENT_ESCALATION, 35, "Duty Admin R. Menon", CaseStatus.OPEN, "10:22 AM"),
    ServiceCase("CASE-105", "Orthopedics Clinic", IssueType.OPD_DELAY, 18, "Front-Office Lead S. Das", CaseStatus.RESOLVED, "08:30 AM")
)
