package com.medflow.ops.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val MedTealPrimary = Color(0xFF0D9488)
val MedTealDark = Color(0xFF0F766E)
val MedTealContainer = Color(0xFFCCFBF1)
val MedSlateNavy = Color(0xFF0F172A)
val MedSlateMuted = Color(0xFF475569)
val MedSurfaceCanvas = Color(0xFFF8FAFC)
val MedCardSurface = Color(0xFFFFFFFF)
val MedOutlineHairline = Color(0xFFE2E8F0)

val MedCriticalRed = Color(0xFFDC2626)
val MedCriticalContainer = Color(0xFFFEF2F2)
val MedWarningAmber = Color(0xFFD97706)
val MedWarningContainer = Color(0xFFFFFBEB)
val MedSuccessGreen = Color(0xFF16A34A)
val MedSuccessContainer = Color(0xFFF0FDF4)

private val MedFlowColorScheme = lightColorScheme(
    primary = MedTealPrimary,
    onPrimary = Color.White,
    primaryContainer = MedTealContainer,
    onPrimaryContainer = MedSlateNavy,
    secondary = MedSlateNavy,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE2E8F0),
    onSecondaryContainer = MedSlateNavy,
    background = MedSurfaceCanvas,
    onBackground = MedSlateNavy,
    surface = MedCardSurface,
    onSurface = MedSlateNavy,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = MedSlateMuted,
    outline = MedOutlineHairline,
    error = MedCriticalRed,
    onError = Color.White
)

private val MedFlowTypography = Typography(
    headlineMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 32.sp,
        color = MedSlateNavy
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 28.sp,
        color = MedSlateNavy
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        color = MedSlateNavy
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        color = MedSlateMuted
    ),
    labelMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun MedFlowOpsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MedFlowColorScheme,
        typography = MedFlowTypography,
        content = content
    )
}
