package com.medflow.ops.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.medflow.ops.model.AlertSeverity
import com.medflow.ops.model.BottleneckAlert
import com.medflow.ops.model.MedFlowScreen
import com.medflow.ops.model.ShiftKpi
import com.medflow.ops.model.UserRole
import com.medflow.ops.theme.MedCardSurface
import com.medflow.ops.theme.MedCriticalRed
import com.medflow.ops.theme.MedOutlineHairline
import com.medflow.ops.theme.MedSlateMuted
import com.medflow.ops.theme.MedSlateNavy
import com.medflow.ops.theme.MedTealPrimary
import com.medflow.ops.theme.MedWarningAmber

@Composable
fun DashboardScreen(
    role: UserRole,
    kpis: List<ShiftKpi>,
    alerts: List<BottleneckAlert>,
    onNavigate: (MedFlowScreen, String?) -> Unit,
    contentPadding: PaddingValues
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Sample Hospital Shift Data · ${role.label}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MedTealPrimary
                )
                Text(
                    text = "Shift Operations Overview",
                    style = MaterialTheme.typography.titleLarge,
                    color = MedSlateNavy
                )
            }
        }

        // 2x2 KPI Summary Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                kpis.chunked(2).forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowItems.forEach { kpi ->
                            KpiSummaryCard(
                                kpi = kpi,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Quick Navigation Buttons
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onNavigate(MedFlowScreen.OPERATIONS, null) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MedTealPrimary,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Assignment,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Bottlenecks", fontWeight = FontWeight.SemiBold)
                }

                OutlinedButton(
                    onClick = { onNavigate(MedFlowScreen.REPORTS, null) },
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MedOutlineHairline),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Assessment,
                        contentDescription = null,
                        tint = MedTealPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Reports", color = MedSlateNavy, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        item {
            Text(
                text = "Department Bottleneck Alerts",
                style = MaterialTheme.typography.titleMedium,
                color = MedSlateNavy
            )
        }

        items(alerts, key = { it.id }) { alert ->
            val severityColor = when (alert.severity) {
                AlertSeverity.CRITICAL -> MedCriticalRed
                AlertSeverity.HIGH -> MedWarningAmber
                AlertSeverity.MODERATE -> MedTealPrimary
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = MedCardSurface),
                border = BorderStroke(1.dp, MedOutlineHairline),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Warning,
                            contentDescription = null,
                            tint = severityColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "${alert.severity.label} · ${alert.department} · ${alert.delayMinutes} mins delay",
                            style = MaterialTheme.typography.labelMedium,
                            color = severityColor
                        )
                    }

                    Text(
                        text = alert.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MedSlateNavy
                    )
                    Text(
                        text = alert.summary,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MedSlateMuted
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Owner: ${alert.owner}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MedSlateMuted
                        )
                        TextButton(
                            onClick = { onNavigate(MedFlowScreen.OPERATIONS, alert.linkedCaseId) }
                        ) {
                            Text("Resolve", color = MedTealPrimary, fontWeight = FontWeight.SemiBold)
                            Icon(
                                imageVector = Icons.AutoMirrored.Outlined.ArrowForward,
                                contentDescription = null,
                                tint = MedTealPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KpiSummaryCard(
    kpi: ShiftKpi,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MedCardSurface),
        border = BorderStroke(1.dp, MedOutlineHairline),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = kpi.label,
                style = MaterialTheme.typography.bodyMedium,
                color = MedSlateMuted
            )
            Text(
                text = kpi.value,
                style = MaterialTheme.typography.headlineMedium,
                color = MedSlateNavy
            )
            HorizontalDivider(color = MedOutlineHairline)
            Text(
                text = kpi.target,
                style = MaterialTheme.typography.labelMedium,
                color = if (kpi.isAlertState) MedWarningAmber else MedTealPrimary
            )
        }
    }
}
