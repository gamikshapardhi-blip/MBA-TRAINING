package com.medflow.ops.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.medflow.ops.model.CaseStatus
import com.medflow.ops.model.IssueType
import com.medflow.ops.model.ServiceCase
import com.medflow.ops.model.SopActionPlan
import com.medflow.ops.theme.MedCardSurface
import com.medflow.ops.theme.MedCriticalRed
import com.medflow.ops.theme.MedOutlineHairline
import com.medflow.ops.theme.MedSlateMuted
import com.medflow.ops.theme.MedSlateNavy
import com.medflow.ops.theme.MedSuccessGreen
import com.medflow.ops.theme.MedTealPrimary
import com.medflow.ops.theme.MedWarningAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OperationsScreen(
    cases: List<ServiceCase>,
    plans: Map<String, SopActionPlan>,
    checkedStepIds: Set<String>,
    focusedCaseId: String?,
    onAddCase: (String, IssueType, Int, String) -> Unit,
    onCycleStatus: (String) -> Unit,
    onGeneratePlan: (ServiceCase) -> Unit,
    onToggleStep: (String) -> Unit,
    contentPadding: PaddingValues
) {
    var departmentInput by remember { mutableStateOf("") }
    var issueTypeInput by remember { mutableStateOf(IssueType.OPD_DELAY) }
    var waitTimeInput by remember { mutableStateOf("35") }
    var ownerInput by remember { mutableStateOf("") }
    var issueDropdownExpanded by remember { mutableStateOf(false) }
    var statusFilter by remember { mutableStateOf<CaseStatus?>(null) }

    val filteredCases = if (statusFilter == null) {
        cases
    } else {
        cases.filter { it.status == statusFilter }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Patient Flow & Bottleneck Resolution",
                    style = MaterialTheme.typography.labelMedium,
                    color = MedTealPrimary
                )
                Text(
                    text = "Log & Resolve Service Bottleneck",
                    style = MaterialTheme.typography.titleLarge,
                    color = MedSlateNavy
                )
            }
        }

        // Input Form Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MedCardSurface),
                border = BorderStroke(1.dp, MedOutlineHairline),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Add New Bottleneck Case",
                        style = MaterialTheme.typography.titleMedium,
                        color = MedSlateNavy
                    )

                    OutlinedTextField(
                        value = departmentInput,
                        onValueChange = { departmentInput = it },
                        label = { Text("Department Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    ExposedDropdownMenuBox(
                        expanded = issueDropdownExpanded,
                        onExpandedChange = { issueDropdownExpanded = !issueDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = issueTypeInput.label,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Issue Type") },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = issueDropdownExpanded)
                            },
                            modifier = Modifier
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = issueDropdownExpanded,
                            onDismissRequest = { issueDropdownExpanded = false }
                        ) {
                            IssueType.entries.forEach { type ->
                                DropdownMenuItem(
                                    text = { Text(type.label) },
                                    onClick = {
                                        issueTypeInput = type
                                        issueDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = waitTimeInput,
                            onValueChange = { waitTimeInput = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Wait (mins)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = ownerInput,
                            onValueChange = { ownerInput = it },
                            label = { Text("Assigned Owner") },
                            singleLine = true,
                            modifier = Modifier.weight(1.6f)
                        )
                    }

                    Button(
                        onClick = {
                            val waitMins = waitTimeInput.toIntOrNull() ?: 0
                            if (departmentInput.isNotBlank() && ownerInput.isNotBlank() && waitMins > 0) {
                                onAddCase(departmentInput, issueTypeInput, waitMins, ownerInput)
                                departmentInput = ""
                                ownerInput = ""
                                waitTimeInput = "30"
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MedTealPrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Log Service Bottleneck", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // Status Filter Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = statusFilter == null,
                    onClick = { statusFilter = null },
                    label = { Text("All (${cases.size})") }
                )
                CaseStatus.entries.forEach { status ->
                    val count = cases.count { it.status == status }
                    FilterChip(
                        selected = statusFilter == status,
                        onClick = { statusFilter = status },
                        label = { Text("${status.label} ($count)") }
                    )
                }
            }
        }

        // Bottleneck Cases List
        items(filteredCases, key = { it.id }) { item ->
            val statusColor = when (item.status) {
                CaseStatus.OPEN -> MedCriticalRed
                CaseStatus.IN_PROGRESS -> MedWarningAmber
                CaseStatus.RESOLVED -> MedSuccessGreen
            }
            val borderStroke = if (focusedCaseId == item.id) {
                BorderStroke(2.dp, MedTealPrimary)
            } else {
                BorderStroke(1.dp, MedOutlineHairline)
            }
            val plan = plans[item.id]

            Card(
                colors = CardDefaults.cardColors(containerColor = MedCardSurface),
                border = borderStroke,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${item.id} · ${item.issueType.label}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MedSlateMuted
                        )
                        Text(
                            text = "${item.waitTimeMinutes} mins · ${item.status.label}",
                            style = MaterialTheme.typography.labelMedium,
                            color = statusColor
                        )
                    }

                    Text(
                        text = item.departmentName,
                        style = MaterialTheme.typography.titleMedium,
                        color = MedSlateNavy
                    )
                    Text(
                        text = "Owner: ${item.assignedOwner} · Logged ${item.loggedAt}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MedSlateMuted
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onCycleStatus(item.id) },
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, MedOutlineHairline),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "Next: ${item.status.next().label}",
                                color = MedSlateNavy
                            )
                        }

                        Button(
                            onClick = { onGeneratePlan(item) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MedTealPrimary,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1.2f)
                        ) {
                            Text("Generate SOP Plan")
                        }
                    }

                    if (plan != null) {
                        HorizontalDivider(color = MedOutlineHairline)
                        Text(
                            text = "${plan.protocolCode} · ${plan.title}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MedTealPrimary
                        )
                        Text(
                            text = "Projected Time Saved: ~${plan.projectedMinutesSaved} mins",
                            style = MaterialTheme.typography.labelMedium,
                            color = MedSuccessGreen
                        )
                        plan.steps.forEach { step ->
                            val isChecked = step.id in checkedStepIds
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onToggleStep(step.id) }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { onToggleStep(step.id) },
                                    colors = CheckboxDefaults.colors(checkedColor = MedTealPrimary)
                                )
                                Column {
                                    Text(
                                        text = "${step.stepNumber}. ${step.action}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MedSlateNavy
                                    )
                                    Text(
                                        text = "${step.ownerRole} · SLA ${step.slaMinutes} mins",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MedSlateMuted
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
