package com.medflow.ops.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.medflow.ops.logic.SopRuleEngine
import com.medflow.ops.model.ServiceCase
import com.medflow.ops.model.UserRole
import com.medflow.ops.theme.MedCardSurface
import com.medflow.ops.theme.MedOutlineHairline
import com.medflow.ops.theme.MedSlateMuted
import com.medflow.ops.theme.MedSlateNavy
import com.medflow.ops.theme.MedTealPrimary

@Composable
fun ReportsScreen(
    role: UserRole,
    cases: List<ServiceCase>,
    contentPadding: PaddingValues
) {
    val metrics = SopRuleEngine.computeSessionMetrics(cases)
    val recommendations = SopRuleEngine.buildRecommendations(cases, role)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Shift Impact & Decision Support · ${role.label}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MedTealPrimary
                )
                Text(
                    text = "Reports & Operational Recommendations",
                    style = MaterialTheme.typography.titleLarge,
                    color = MedSlateNavy
                )
            }
        }

        // Dynamic Summary Metrics Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ReportMetricTile(
                        label = "Total Cases Reviewed",
                        value = "${metrics.totalCasesReviewed}",
                        modifier = Modifier.weight(1f)
                    )
                    ReportMetricTile(
                        label = "Resolved Count",
                        value = "${metrics.resolvedCount}",
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ReportMetricTile(
                        label = "Avg Delay Minutes",
                        value = "${metrics.averageDelayMinutes} mins",
                        modifier = Modifier.weight(1f)
                    )
                    ReportMetricTile(
                        label = "Projected Time Saved",
                        value = "${metrics.projectedTimeSavedMinutes} mins",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        item {
            Text(
                text = "Operational Recommendations",
                style = MaterialTheme.typography.titleMedium,
                color = MedSlateNavy
            )
        }

        items(recommendations, key = { it.id }) { rec ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MedCardSurface),
                border = BorderStroke(1.dp, MedOutlineHairline),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = rec.category.label,
                        style = MaterialTheme.typography.labelMedium,
                        color = MedTealPrimary
                    )
                    Text(
                        text = rec.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MedSlateNavy
                    )
                    Text(
                        text = rec.rationale,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MedSlateMuted
                    )
                    HorizontalDivider(color = MedOutlineHairline)
                    Text(
                        text = "Action: ${rec.actionItem}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MedSlateNavy
                    )
                    Text(
                        text = rec.impactLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = MedTealPrimary
                    )
                }
            }
        }

        // Evaluation Disclaimer Footer
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MedCardSurface),
                border = BorderStroke(1.dp, MedOutlineHairline),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Note: Metrics and recommendations displayed in this prototype use sample hospital operational data and rule-based logic for evaluation purposes.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MedSlateMuted,
                    modifier = Modifier.padding(14.dp)
                )
            }
        }
    }
}

@Composable
private fun ReportMetricTile(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MedCardSurface),
        border = BorderStroke(1.dp, MedOutlineHairline),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MedSlateMuted
            )
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                color = MedSlateNavy
            )
        }
    }
}
