package com.medflow.ops.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.medflow.ops.model.UserRole
import com.medflow.ops.theme.MedCardSurface
import com.medflow.ops.theme.MedOutlineHairline
import com.medflow.ops.theme.MedSlateMuted
import com.medflow.ops.theme.MedSlateNavy
import com.medflow.ops.theme.MedSurfaceCanvas
import com.medflow.ops.theme.MedTealPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WelcomeScreen(
    selectedRole: UserRole,
    onSelectRole: (UserRole) -> Unit,
    onEnterWorkspace: () -> Unit
) {
    var roleMenuExpanded by remember { mutableStateOf(false) }

    val capabilities = listOf(
        "OPD Queue Tracking" to "Monitor clinic wait times against shift targets and spot walk-in surges early.",
        "Discharge TAT Monitoring" to "Track ward bed turnover across pharmacy clearance, billing, and housekeeping.",
        "SOP Compliance" to "Generate rule-based mitigation plans with clear owner steps and live audit metrics."
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MedSurfaceCanvas)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "MedFlow Ops",
                style = MaterialTheme.typography.headlineMedium,
                color = MedSlateNavy
            )
            Text(
                text = "Hospital Service Improvement & Shift Flow Manager",
                style = MaterialTheme.typography.titleMedium,
                color = MedTealPrimary
            )
            Text(
                text = "Coordinate OPD queues, discharge turnaround, and shift SOP compliance from one reactive workspace.",
                style = MaterialTheme.typography.bodyMedium,
                color = MedSlateMuted
            )
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MedCardSurface),
            border = BorderStroke(1.dp, MedOutlineHairline),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Core Shift Capabilities",
                    style = MaterialTheme.typography.titleMedium,
                    color = MedSlateNavy
                )
                HorizontalDivider(color = MedOutlineHairline)
                capabilities.forEach { (title, desc) ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.CheckCircle,
                            contentDescription = null,
                            tint = MedTealPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MedSlateNavy
                            )
                            Text(
                                text = desc,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MedSlateMuted
                            )
                        }
                    }
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MedCardSurface),
            border = BorderStroke(1.dp, MedOutlineHairline),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Select Shift Leadership Role",
                    style = MaterialTheme.typography.titleMedium,
                    color = MedSlateNavy
                )

                ExposedDropdownMenuBox(
                    expanded = roleMenuExpanded,
                    onExpandedChange = { roleMenuExpanded = !roleMenuExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedRole.label,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Active Shift Role") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = roleMenuExpanded)
                        },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                    )

                    ExposedDropdownMenu(
                        expanded = roleMenuExpanded,
                        onDismissRequest = { roleMenuExpanded = false }
                    ) {
                        UserRole.entries.forEach { role ->
                            DropdownMenuItem(
                                text = { Text(role.label) },
                                onClick = {
                                    onSelectRole(role)
                                    roleMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Button(
                    onClick = onEnterWorkspace,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MedTealPrimary,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Text(
                        text = "Enter Operations Workspace",
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
