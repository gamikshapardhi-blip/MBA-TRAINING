import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { INDIAN_HUBS, TRAVEL_OFFERINGS } from './src/data/indiaSeed.ts';
import type {
  BookingRecord,
  ClassTier,
  CreateBookingPayload,
  QuoteBreakdown,
  TravelOffering,
  UserSession,
} from './src/types/travel.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.resolve(__dirname, '.data');
const STORE_PATH = path.join(DATA_DIR, 'bharatyatra.json');

interface PersistedStore {
  bookings: BookingRecord[];
  sessions: Record<string, UserSession>;
}

const INITIAL_BOOKINGS: BookingRecord[] = [
  {
    pnrCode: 'BY-849201',
    offeringId: 'pkg-kerala-backwaters-5d',
    offeringTitle: 'Kerala Backwaters, Tea Hills & Kochi',
    mode: 'Package',
    originCode: 'COK',
    originCity: 'Kochi',
    destinationCode: 'COK',
    destinationCity: 'Alleppey & Munnar',
    durationLabel: '5 Days / 4 Nights',
    departureDate: '2026-12-18',
    returnDate: '2026-12-22',
    departureTime: '08:30',
    travelers: 2,
    classTier: 'Comfort',
    selectedAddons: [
      { id: 'addon-airport-pickup', name: 'Private Airport & Rail Transfers', priceInr: 1850 },
    ],
    fare: {
      offeringId: 'pkg-kerala-backwaters-5d',
      travelers: 2,
      classTier: 'Comfort',
      classMultiplier: 1.2,
      baseFarePerPerson: 31799,
      baseSubtotal: 63598,
      addonsTotal: 1850,
      gstAmount: 3272,
      convenienceFee: 299,
      promoCode: 'INDIA5',
      promoDiscount: 3272,
      promoMessage: 'INDIA5 applied — 5% instant savings on base + add-ons',
      grandTotal: 65747,
    },
    contactEmail: 'arjun.mehta@example.in',
    contactPhone: '+91 9820145120',
    travelerDetails: [
      { fullName: 'Arjun Mehta', age: 32, gender: 'Male' },
      { fullName: 'Neha Sharma', age: 30, gender: 'Female' },
    ],
    paymentMethod: 'UPI',
    paymentLastFour: 'arjun@okicici',
    status: 'Upcoming',
    createdAt: '2026-11-12T10:20:00.000Z',
    imageKey: 'kerala',
  },
  {
    pnrCode: 'BY-410935',
    offeringId: 'trn-del-jai-vb',
    offeringTitle: 'Ajmer Shatabdi / Vande Bharat Express',
    mode: 'Vande Bharat',
    originCode: 'DEL',
    originCity: 'New Delhi',
    destinationCode: 'JAI',
    destinationCity: 'Jaipur',
    durationLabel: '4h 15m · High-Speed Rail',
    departureDate: '2026-10-04',
    returnDate: '2026-10-04',
    departureTime: '06:40',
    travelers: 1,
    classTier: 'Executive',
    selectedAddons: [],
    fare: {
      offeringId: 'trn-del-jai-vb',
      travelers: 1,
      classTier: 'Executive',
      classMultiplier: 1.45,
      baseFarePerPerson: 2436,
      baseSubtotal: 2436,
      addonsTotal: 0,
      gstAmount: 122,
      convenienceFee: 299,
      promoCode: null,
      promoDiscount: 0,
      promoMessage: null,
      grandTotal: 2857,
    },
    contactEmail: 'arjun.mehta@example.in',
    contactPhone: '+91 9820145120',
    travelerDetails: [{ fullName: 'Arjun Mehta', age: 32, gender: 'Male' }],
    paymentMethod: 'Card',
    paymentLastFour: '4242',
    status: 'Completed',
    createdAt: '2026-09-25T14:15:00.000Z',
    imageKey: 'rajasthan',
  },
];

function ensureStore(): PersistedStore {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(STORE_PATH)) {
    const initial: PersistedStore = { bookings: INITIAL_BOOKINGS, sessions: {} };
    fs.writeFileSync(STORE_PATH, JSON.stringify(initial, null, 2), 'utf-8');
    return initial;
  }
  try {
    const raw = fs.readFileSync(STORE_PATH, 'utf-8');
    const parsed = JSON.parse(raw) as PersistedStore;
    return {
      bookings: Array.isArray(parsed.bookings) ? parsed.bookings : INITIAL_BOOKINGS,
      sessions: parsed.sessions && typeof parsed.sessions === 'object' ? parsed.sessions : {},
    };
  } catch {
    return { bookings: INITIAL_BOOKINGS, sessions: {} };
  }
}

function writeStore(store: PersistedStore): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2), 'utf-8');
}

function getClassMultiplier(tier: ClassTier): number {
  switch (tier) {
    case 'Comfort':
      return 1.2;
    case 'Executive':
      return 1.45;
    case 'Standard':
    default:
      return 1;
  }
}

function computeQuote(
  offering: TravelOffering,
  travelers: number,
  classTier: ClassTier,
  selectedAddonIds: string[],
  promoInput?: string,
): QuoteBreakdown {
  const safeTravelers = Math.max(1, Math.min(9, Math.floor(travelers || 1)));
  const multiplier = getClassMultiplier(classTier);
  const baseFarePerPerson = Math.round(offering.basePriceInr * multiplier);
  const baseSubtotal = baseFarePerPerson * safeTravelers;

  let addonsTotal = 0;
  for (const addon of offering.addons) {
    if (selectedAddonIds.includes(addon.id)) {
      addonsTotal += addon.perTraveler ? addon.priceInr * safeTravelers : addon.priceInr;
    }
  }

  const taxableSubtotal = baseSubtotal + addonsTotal;
  const gstAmount = Math.round(taxableSubtotal * 0.05);
  const convenienceFee = 299;

  const cleanPromo = (promoInput || '').trim().toUpperCase();
  let promoCode: string | null = null;
  let promoDiscount = 0;
  let promoMessage: string | null = null;

  if (cleanPromo === 'INDIA5') {
    promoCode = 'INDIA5';
    promoDiscount = Math.round(taxableSubtotal * 0.05);
    promoMessage = 'INDIA5 applied — 5% instant savings on base + add-ons';
  } else if (cleanPromo === 'YATRA1000') {
    if (taxableSubtotal >= 12000) {
      promoCode = 'YATRA1000';
      promoDiscount = 1000;
      promoMessage = 'YATRA1000 applied — ₹1,000 flat savings';
    } else {
      promoMessage = 'YATRA1000 requires a minimum trip value of ₹12,000';
    }
  } else if (cleanPromo.length > 0) {
    promoMessage = `Code "${cleanPromo}" is not recognized. Try INDIA5 or YATRA1000.`;
  }

  const grandTotal = Math.max(0, taxableSubtotal + gstAmount + convenienceFee - promoDiscount);

  return {
    offeringId: offering.id,
    travelers: safeTravelers,
    classTier,
    classMultiplier: multiplier,
    baseFarePerPerson,
    baseSubtotal,
    addonsTotal,
    gstAmount,
    convenienceFee,
    promoCode,
    promoDiscount,
    promoMessage,
    grandTotal,
  };
}

function generatePnr(existingPnrs: Set<string>): string {
  for (let i = 0; i < 20; i += 1) {
    const code = `BY-${Math.floor(100000 + Math.random() * 899999)}`;
    if (!existingPnrs.has(code)) return code;
  }
  return `BY-${Date.now().toString().slice(-6)}`;
}

async function startServer() {
  const app = express();
  app.use(express.json());

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'BharatYatra API' });
  });

  app.get('/api/hubs', (req, res) => {
    const q = String(req.query.q || '').trim().toLowerCase();
    if (!q) {
      return res.json({ hubs: INDIAN_HUBS });
    }
    const filtered = INDIAN_HUBS.filter(
      (h) =>
        h.city.toLowerCase().includes(q) ||
        h.code.toLowerCase().includes(q) ||
        h.state.toLowerCase().includes(q),
    );
    return res.json({ hubs: filtered });
  });

  app.get('/api/offerings', (req, res) => {
    const category = String(req.query.category || '');
    const origin = String(req.query.origin || '').trim().toLowerCase();
    const destination = String(req.query.destination || '').trim().toLowerCase();
    const mode = String(req.query.mode || '').trim();
    const departureSlot = String(req.query.departureSlot || '').trim();
    const maxPrice = Number(req.query.maxPrice || 0);
    const maxDurationDays = Number(req.query.maxDurationDays || 0);
    const minRating = Number(req.query.minRating || 0);
    const freeCancellation = req.query.freeCancellation === 'true';
    const fiveDayOnly = req.query.fiveDayOnly === 'true';
    const sort = String(req.query.sort || 'recommended');
    const q = String(req.query.q || '').trim().toLowerCase();

    let results = [...TRAVEL_OFFERINGS];

    if (category && category !== 'all') {
      results = results.filter((o) => o.category === category);
    }
    if (origin) {
      results = results.filter(
        (o) =>
          o.originCity.toLowerCase().includes(origin) ||
          o.originCode.toLowerCase() === origin,
      );
    }
    if (destination) {
      results = results.filter(
        (o) =>
          o.destinationCity.toLowerCase().includes(destination) ||
          o.destinationCode.toLowerCase() === destination ||
          o.title.toLowerCase().includes(destination) ||
          o.subtitle.toLowerCase().includes(destination) ||
          o.region.toLowerCase().includes(destination),
      );
    }
    if (q) {
      results = results.filter(
        (o) =>
          o.title.toLowerCase().includes(q) ||
          o.subtitle.toLowerCase().includes(q) ||
          o.originCity.toLowerCase().includes(q) ||
          o.destinationCity.toLowerCase().includes(q) ||
          o.originCode.toLowerCase().includes(q) ||
          o.destinationCode.toLowerCase().includes(q),
      );
    }
    if (mode && mode !== 'all') {
      results = results.filter((o) => o.mode === mode);
    }
    if (departureSlot && departureSlot !== 'all') {
      results = results.filter((o) => o.departureWindow === departureSlot);
    }
    if (maxPrice > 0) {
      results = results.filter((o) => o.basePriceInr <= maxPrice);
    }
    if (maxDurationDays > 0) {
      results = results.filter((o) => o.durationDays <= maxDurationDays);
    }
    if (minRating > 0) {
      results = results.filter((o) => o.rating >= minRating);
    }
    if (freeCancellation) {
      results = results.filter((o) => o.freeCancellation);
    }
    if (fiveDayOnly) {
      results = results.filter((o) => o.isFiveDayEscape);
    }

    if (sort === 'price_asc') {
      results.sort((a, b) => a.basePriceInr - b.basePriceInr);
    } else if (sort === 'price_desc') {
      results.sort((a, b) => b.basePriceInr - a.basePriceInr);
    } else if (sort === 'fastest') {
      results.sort((a, b) => a.durationMinutes - b.durationMinutes);
    } else if (sort === 'rating') {
      results.sort((a, b) => b.rating - a.rating || b.reviewCount - a.reviewCount);
    } else {
      results.sort((a, b) => b.reviewCount * b.rating - a.reviewCount * a.rating);
    }

    res.json({ offerings: results, total: results.length });
  });

  app.get('/api/offerings/:id', (req, res) => {
    const offering = TRAVEL_OFFERINGS.find((o) => o.id === req.params.id);
    if (!offering) {
      return res.status(404).json({ error: 'Offering not found' });
    }
    return res.json({ offering });
  });

  app.post('/api/quote', (req, res) => {
    const {
      offeringId,
      travelers = 2,
      classTier = 'Standard',
      selectedAddonIds = [],
      promoCode = '',
    } = req.body as {
      offeringId?: string;
      travelers?: number;
      classTier?: ClassTier;
      selectedAddonIds?: string[];
      promoCode?: string;
    };

    const offering = TRAVEL_OFFERINGS.find((o) => o.id === offeringId);
    if (!offering) {
      return res.status(404).json({ error: 'Selected trip or route was not found.' });
    }

    const quote = computeQuote(
      offering,
      Number(travelers),
      classTier,
      Array.isArray(selectedAddonIds) ? selectedAddonIds : [],
      promoCode,
    );
    return res.json({ quote });
  });

  app.get('/api/bookings', (req, res) => {
    const store = ensureStore();
    const email = String(req.query.email || '').trim().toLowerCase();
    const list = email
      ? store.bookings.filter((b) => b.contactEmail.toLowerCase() === email)
      : store.bookings;
    res.json({ bookings: list });
  });

  app.post('/api/bookings', (req, res) => {
    const payload = req.body as CreateBookingPayload;
    const offering = TRAVEL_OFFERINGS.find((o) => o.id === payload.offeringId);
    if (!offering) {
      return res.status(404).json({ error: 'Selected offering not found.' });
    }

    const cleanedPhone = String(payload.contactPhone || '')
      .replace(/[\s-]/g, '')
      .replace(/^\+91/, '');
    if (!/^[6-9]\d{9}$/.test(cleanedPhone)) {
      return res.status(400).json({
        error: 'Please enter a valid 10-digit Indian mobile number starting with 6-9.',
      });
    }

    if (!payload.contactEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(payload.contactEmail.trim())) {
      return res.status(400).json({ error: 'Please provide a valid email address for your e-ticket.' });
    }

    if (
      payload.gstin &&
      payload.gstin.trim() &&
      !/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(
        payload.gstin.trim().toUpperCase(),
      )
    ) {
      return res.status(400).json({ error: 'GSTIN format appears invalid (expected 15 alphanumeric characters).' });
    }

    if (!Array.isArray(payload.travelerDetails) || payload.travelerDetails.length === 0) {
      return res.status(400).json({ error: 'At least one traveler detail is required.' });
    }

    for (const traveler of payload.travelerDetails) {
      if (!traveler.fullName || traveler.fullName.trim().length < 2) {
        return res.status(400).json({ error: 'Each traveler must include a full name.' });
      }
      if (!traveler.age || traveler.age < 1 || traveler.age > 110) {
        return res.status(400).json({ error: 'Each traveler age must be between 1 and 110.' });
      }
    }

    const quote = computeQuote(
      offering,
      payload.travelers,
      payload.classTier || 'Standard',
      Array.isArray(payload.selectedAddonIds) ? payload.selectedAddonIds : [],
      payload.promoCode,
    );

    const selectedAddons = offering.addons
      .filter((a) => (payload.selectedAddonIds || []).includes(a.id))
      .map((a) => ({
        id: a.id,
        name: a.name,
        priceInr: a.perTraveler ? a.priceInr * quote.travelers : a.priceInr,
      }));

    const store = ensureStore();
    const existingPnrs = new Set(store.bookings.map((b) => b.pnrCode));
    const pnrCode = generatePnr(existingPnrs);

    const cleanIdentifier = String(payload.paymentIdentifier || '').trim();
    const paymentLastFour =
      payload.paymentMethod === 'Card'
        ? cleanIdentifier.slice(-4) || '4242'
        : cleanIdentifier || payload.paymentMethod;

    const record: BookingRecord = {
      pnrCode,
      offeringId: offering.id,
      offeringTitle: offering.title,
      mode: offering.mode,
      originCode: offering.originCode,
      originCity: offering.originCity,
      destinationCode: offering.destinationCode,
      destinationCity: offering.destinationCity,
      durationLabel: offering.durationLabel,
      departureDate: payload.departureDate,
      returnDate: payload.returnDate || payload.departureDate,
      departureTime: offering.departureTime,
      travelers: quote.travelers,
      classTier: quote.classTier,
      selectedAddons,
      fare: quote,
      contactEmail: payload.contactEmail.trim(),
      contactPhone: `+91 ${cleanedPhone}`,
      gstin: payload.gstin ? payload.gstin.trim().toUpperCase() : undefined,
      travelerDetails: payload.travelerDetails.map((t) => ({
        fullName: t.fullName.trim(),
        age: Number(t.age),
        gender: t.gender,
      })),
      paymentMethod: payload.paymentMethod || 'UPI',
      paymentLastFour,
      status: 'Upcoming',
      createdAt: new Date().toISOString(),
      imageKey: offering.imageKey,
    };

    store.bookings.unshift(record);
    writeStore(store);

    return res.status(201).json({ booking: record });
  });

  app.patch('/api/bookings/:pnr', (req, res) => {
    const store = ensureStore();
    const idx = store.bookings.findIndex((b) => b.pnrCode === req.params.pnr);
    if (idx === -1) {
      return res.status(404).json({ error: 'Booking PNR not found.' });
    }

    const booking = store.bookings[idx];
    const { action, newDate } = req.body as { action?: 'cancel' | 'reschedule'; newDate?: string };

    if (action === 'cancel') {
      if (booking.status === 'Cancelled') {
        return res.status(400).json({ error: 'This booking is already cancelled.' });
      }
      store.bookings[idx] = { ...booking, status: 'Cancelled' };
      writeStore(store);
      return res.json({ booking: store.bookings[idx] });
    }

    if (action === 'reschedule') {
      if (!newDate) {
        return res.status(400).json({ error: 'Please select a new departure date.' });
      }
      if (booking.status === 'Cancelled') {
        return res.status(400).json({ error: 'Cancelled bookings cannot be rescheduled.' });
      }
      store.bookings[idx] = {
        ...booking,
        rescheduledFrom: booking.departureDate,
        departureDate: newDate,
      };
      writeStore(store);
      return res.json({ booking: store.bookings[idx] });
    }

    return res.status(400).json({ error: 'Invalid booking action.' });
  });

  app.post('/api/auth/login', (req, res) => {
    const { name, email, phone } = req.body as Partial<UserSession>;
    if (!name || name.trim().length < 2) {
      return res.status(400).json({ error: 'Please enter your full name.' });
    }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      return res.status(400).json({ error: 'Please enter a valid email address.' });
    }
    const cleanedPhone = String(phone || '')
      .replace(/[\s-]/g, '')
      .replace(/^\+91/, '');
    if (cleanedPhone && !/^[6-9]\d{9}$/.test(cleanedPhone)) {
      return res.status(400).json({ error: 'Please enter a valid 10-digit Indian mobile number.' });
    }

    const token = `by_sess_${Math.random().toString(36).slice(2, 14)}`;
    const session: UserSession = {
      name: name.trim(),
      email: email.trim(),
      phone: cleanedPhone ? `+91 ${cleanedPhone}` : '+91 9820145120',
    };

    const store = ensureStore();
    store.sessions[token] = session;
    writeStore(store);

    return res.json({ token, user: session });
  });

  app.get('/api/auth/me', (req, res) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '').trim();
    if (!token) {
      return res.json({ user: null });
    }
    const store = ensureStore();
    return res.json({ user: store.sessions[token] || null });
  });

  app.post('/api/auth/logout', (req, res) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '').trim();
    if (token) {
      const store = ensureStore();
      delete store.sessions[token];
      writeStore(store);
    }
    return res.json({ ok: true });
  });

  if (process.env.NODE_ENV === 'production') {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const PORT = Number(process.env.PORT || 3000);
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BharatYatra server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
