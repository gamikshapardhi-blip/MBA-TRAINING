/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { useEffect, useState } from 'react';
import { AuthModal } from './components/AuthModal';
import { CheckoutView } from './components/CheckoutView';
import { EscapesShowcase } from './components/EscapesShowcase';
import { Footer } from './components/Footer';
import { HeroSearch } from './components/HeroSearch';
import { MyTripsView } from './components/MyTripsView';
import { Navbar, type AppView } from './components/Navbar';
import { OfferingDetailView } from './components/OfferingDetailView';
import { SearchResultsView } from './components/SearchResultsView';
import { TRAVEL_OFFERINGS } from './data/indiaSeed';
import type {
  BookingRecord,
  ClassTier,
  QuoteBreakdown,
  SearchQuery,
  TravelOffering,
  UserSession,
} from './types/travel';

const SESSION_STORAGE_KEY = 'bharatyatra_session_token';

export default function App() {
  const [view, setView] = useState<AppView>('home');
  const [searchQuery, setSearchQuery] = useState<SearchQuery>({
    category: 'packages',
    origin: '',
    destination: '',
    departureDate: '2026-12-10',
    returnDate: '2026-12-14',
    travelers: 2,
    classTier: 'Standard',
  });
  const [fiveDayFilterPreset, setFiveDayFilterPreset] = useState(false);

  const [selectedOffering, setSelectedOffering] = useState<TravelOffering | null>(null);
  const [checkoutConfig, setCheckoutConfig] = useState<{
    offering: TravelOffering;
    departureDate: string;
    returnDate: string;
    travelers: number;
    classTier: ClassTier;
    selectedAddonIds: string[];
    quote: QuoteBreakdown;
  } | null>(null);

  const [justConfirmedPnr, setJustConfirmedPnr] = useState<string | null>(null);
  const [user, setUser] = useState<UserSession | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem(SESSION_STORAGE_KEY);
    if (!token) return;
    fetch('/api/auth/me', {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => res.json())
      .then((data: { user?: UserSession | null }) => {
        if (data.user) setUser(data.user);
      })
      .catch(() => {
        localStorage.removeItem(SESSION_STORAGE_KEY);
      });
  }, []);

  const handleSignOut = async () => {
    const token = localStorage.getItem(SESSION_STORAGE_KEY);
    if (token) {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      }).catch(() => undefined);
      localStorage.removeItem(SESSION_STORAGE_KEY);
    }
    setUser(null);
  };

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

  const openSearchResults = (query: SearchQuery, fiveDayOnly = false) => {
    setSearchQuery(query);
    setFiveDayFilterPreset(fiveDayOnly);
    setView('results');
    scrollToTop();
  };

  const openOfferingDetail = (offering: TravelOffering) => {
    setSelectedOffering(offering);
    setView('detail');
    scrollToTop();
  };

  const fiveDayEscapes = TRAVEL_OFFERINGS.filter((o) => o.isFiveDayEscape).slice(0, 6);
  const transitHighlights = TRAVEL_OFFERINGS.filter(
    (o) => o.category === 'flights_trains' || o.category === 'buses_cabs',
  ).slice(0, 6);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <Navbar
        activeView={view}
        onNavigateHome={() => {
          setView('home');
          scrollToTop();
        }}
        onNavigateEscapes={() =>
          openSearchResults({ ...searchQuery, category: 'packages', origin: '', destination: '' }, true)
        }
        onNavigateTransit={() =>
          openSearchResults({ ...searchQuery, category: 'flights_trains', origin: '', destination: '' }, false)
        }
        onNavigateTrips={() => {
          setJustConfirmedPnr(null);
          setView('trips');
          scrollToTop();
        }}
        user={user}
        onOpenAuth={() => setAuthModalOpen(true)}
        onSignOut={handleSignOut}
      />

      <main className="flex-1">
        {view === 'home' && (
          <>
            <HeroSearch
              initialQuery={searchQuery}
              onSearch={(q) => openSearchResults(q, false)}
            />
            <EscapesShowcase
              fiveDayEscapes={fiveDayEscapes}
              transitHighlights={transitHighlights}
              onSelectOffering={openOfferingDetail}
              onViewAllEscapes={() =>
                openSearchResults(
                  { ...searchQuery, category: 'packages', origin: '', destination: '' },
                  true,
                )
              }
              onViewAllTransit={() =>
                openSearchResults(
                  { ...searchQuery, category: 'flights_trains', origin: '', destination: '' },
                  false,
                )
              }
            />
          </>
        )}

        {view === 'results' && (
          <SearchResultsView
            query={searchQuery}
            fiveDayOnlyInitial={fiveDayFilterPreset}
            onUpdateQuery={setSearchQuery}
            onSelectOffering={openOfferingDetail}
            onBackHome={() => {
              setView('home');
              scrollToTop();
            }}
          />
        )}

        {view === 'detail' && selectedOffering && (
          <OfferingDetailView
            offering={selectedOffering}
            initialDepartureDate={searchQuery.departureDate}
            initialTravelers={searchQuery.travelers}
            initialClassTier={searchQuery.classTier}
            onBack={() => {
              setView('results');
              scrollToTop();
            }}
            onProceedCheckout={(config) => {
              setCheckoutConfig(config);
              setView('checkout');
              scrollToTop();
            }}
          />
        )}

        {view === 'checkout' && checkoutConfig && (
          <CheckoutView
            offering={checkoutConfig.offering}
            departureDate={checkoutConfig.departureDate}
            returnDate={checkoutConfig.returnDate}
            travelers={checkoutConfig.travelers}
            classTier={checkoutConfig.classTier}
            selectedAddonIds={checkoutConfig.selectedAddonIds}
            initialQuote={checkoutConfig.quote}
            user={user}
            onBack={() => {
              setView('detail');
              scrollToTop();
            }}
            onBookingConfirmed={(booking: BookingRecord) => {
              setJustConfirmedPnr(booking.pnrCode);
              setView('trips');
              scrollToTop();
            }}
          />
        )}

        {view === 'trips' && (
          <MyTripsView
            justConfirmedPnr={justConfirmedPnr}
            user={user}
            onExploreTrips={() =>
              openSearchResults(
                { ...searchQuery, category: 'packages', origin: '', destination: '' },
                true,
              )
            }
          />
        )}
      </main>

      <Footer
        onNavigateEscapes={() =>
          openSearchResults({ ...searchQuery, category: 'packages', origin: '', destination: '' }, true)
        }
        onNavigateTransit={() =>
          openSearchResults({ ...searchQuery, category: 'flights_trains', origin: '', destination: '' }, false)
        }
        onNavigateTrips={() => {
          setJustConfirmedPnr(null);
          setView('trips');
          scrollToTop();
        }}
      />

      {authModalOpen && (
        <AuthModal
          onClose={() => setAuthModalOpen(false)}
          onSignedIn={(signedUser, token) => {
            localStorage.setItem(SESSION_STORAGE_KEY, token);
            setUser(signedUser);
          }}
        />
      )}
    </div>
  );
}
