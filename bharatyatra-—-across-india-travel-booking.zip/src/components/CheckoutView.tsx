import { ArrowLeft, CheckCircle2, CreditCard, Landmark, Lock, Smartphone, Wallet } from 'lucide-react';
import { useEffect, useState } from 'react';
import {
  formatDisplayDate,
  formatInr,
  isValidEmail,
  isValidGstin,
  isValidIndianPhone,
} from '../lib/format';
import type {
  BookingRecord,
  ClassTier,
  PaymentMethod,
  QuoteBreakdown,
  TravelOffering,
  TravelerInput,
  UserSession,
} from '../types/travel';

interface CheckoutViewProps {
  offering: TravelOffering;
  departureDate: string;
  returnDate: string;
  travelers: number;
  classTier: ClassTier;
  selectedAddonIds: string[];
  initialQuote: QuoteBreakdown;
  user: UserSession | null;
  onBack: () => void;
  onBookingConfirmed: (booking: BookingRecord) => void;
}

export function CheckoutView({
  offering,
  departureDate,
  returnDate,
  travelers,
  classTier,
  selectedAddonIds,
  initialQuote,
  user,
  onBack,
  onBookingConfirmed,
}: CheckoutViewProps) {
  const [quote, setQuote] = useState<QuoteBreakdown>(initialQuote);
  const [promoInput, setPromoInput] = useState('');
  const [applyingPromo, setApplyingPromo] = useState(false);

  const [contactEmail, setContactEmail] = useState(user?.email || '');
  const [contactPhone, setContactPhone] = useState(
    user?.phone ? user.phone.replace(/^\+91\s*/, '') : '',
  );
  const [gstin, setGstin] = useState('');
  const [travelerDetails, setTravelerDetails] = useState<TravelerInput[]>(() =>
    Array.from({ length: travelers }, (_, idx) => ({
      fullName: idx === 0 && user?.name ? user.name : '',
      age: 28,
      gender: 'Male',
    })),
  );

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [upiId, setUpiId] = useState('traveler@okicici');
  const [cardNumber, setCardNumber] = useState('4242 4242 4242 4242');
  const [cardExpiry, setCardExpiry] = useState('08/29');
  const [bankName, setBankName] = useState('HDFC Bank');

  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    setTravelerDetails((prev) => {
      if (prev.length === travelers) return prev;
      return Array.from({ length: travelers }, (_, idx) => prev[idx] || {
        fullName: '',
        age: 28,
        gender: 'Male',
      });
    });
  }, [travelers]);

  const handleApplyPromo = async () => {
    setApplyingPromo(true);
    try {
      const res = await fetch('/api/quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          offeringId: offering.id,
          travelers,
          classTier,
          selectedAddonIds,
          promoCode: promoInput,
        }),
      });
      if (res.ok) {
        const data = (await res.json()) as { quote: QuoteBreakdown };
        setQuote(data.quote);
      }
    } finally {
      setApplyingPromo(false);
    }
  };

  const updateTraveler = (idx: number, patch: Partial<TravelerInput>) => {
    setTravelerDetails((prev) =>
      prev.map((item, i) => (i === idx ? { ...item, ...patch } : item)),
    );
  };

  const handleConfirmBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!isValidEmail(contactEmail)) {
      setErrorMsg('Please enter a valid email address for receiving your e-ticket.');
      return;
    }
    if (!isValidIndianPhone(contactPhone)) {
      setErrorMsg('Please enter a valid 10-digit Indian mobile number starting with 6–9.');
      return;
    }
    if (!isValidGstin(gstin)) {
      setErrorMsg('GSTIN must be 15 alphanumeric characters (e.g. 27AABCU9603R1ZM).');
      return;
    }
    for (let i = 0; i < travelerDetails.length; i += 1) {
      if (travelerDetails[i].fullName.trim().length < 2) {
        setErrorMsg(`Please enter full name (as per Aadhaar/Passport) for Traveler ${i + 1}.`);
        return;
      }
      if (travelerDetails[i].age < 1 || travelerDetails[i].age > 110) {
        setErrorMsg(`Please enter a valid age for Traveler ${i + 1}.`);
        return;
      }
    }

    const paymentIdentifier =
      paymentMethod === 'UPI'
        ? upiId
        : paymentMethod === 'Card'
          ? cardNumber.replace(/\s+/g, '')
          : paymentMethod === 'NetBanking'
            ? bankName
            : 'Paytm / PhonePe Wallet';

    if (paymentMethod === 'UPI' && !upiId.includes('@')) {
      setErrorMsg('Please enter a valid UPI ID (e.g., name@okicici).');
      return;
    }
    if (paymentMethod === 'Card' && cardNumber.replace(/\s+/g, '').length < 12) {
      setErrorMsg('Please enter a valid card number.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          offeringId: offering.id,
          departureDate,
          returnDate,
          travelers,
          classTier,
          selectedAddonIds,
          promoCode: quote.promoCode || promoInput,
          contactEmail,
          contactPhone,
          gstin: gstin.trim() || undefined,
          travelerDetails,
          paymentMethod,
          paymentIdentifier,
        }),
      });
      const data = (await res.json()) as { booking?: BookingRecord; error?: string };
      if (!res.ok || !data.booking) {
        throw new Error(data.error || 'Could not complete booking.');
      }
      onBookingConfirmed(data.booking);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Checkout failed. Please retry.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-slate-50 min-h-[calc(100vh-4rem)] pb-16">
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 hover:text-slate-900 cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to trip details</span>
          </button>
          <span className="inline-flex items-center gap-1.5 text-xs text-slate-500">
            <Lock className="h-3.5 w-3.5 text-emerald-700" />
            <span>256-bit Encrypted Indian Checkout</span>
          </span>
        </div>
      </div>

      <form
        onSubmit={handleConfirmBooking}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start"
      >
        <div className="lg:col-span-8 space-y-6">
          <section className="bg-white border border-slate-200 rounded-xl p-6">
            <h1 className="font-display text-2xl font-semibold text-slate-900 mb-1">
              Traveler &amp; Contact Information
            </h1>
            <p className="text-xs text-slate-500 mb-5">
              PNR &amp; GST tax invoice will be sent immediately to this email and +91 number.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  placeholder="name@example.in"
                  className="w-full h-11 px-3 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-900 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Indian Mobile Number *
                </label>
                <div className="flex">
                  <span className="inline-flex items-center px-3 h-11 text-sm font-mono text-slate-700 bg-slate-100 border border-r-0 border-slate-200 rounded-l-lg">
                    +91
                  </span>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                    placeholder="9820145120"
                    className="w-full h-11 px-3 text-sm bg-slate-50 border border-slate-200 rounded-r-lg focus:outline-none focus:border-indigo-900 focus:bg-white tabular-nums"
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Company GSTIN (Optional for Business Input Tax Credit)
                </label>
                <input
                  type="text"
                  maxLength={15}
                  value={gstin}
                  onChange={(e) => setGstin(e.target.value.toUpperCase())}
                  placeholder="e.g. 27AABCU9603R1ZM"
                  className="w-full h-11 px-3 text-sm font-mono bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-900 focus:bg-white uppercase"
                />
              </div>
            </div>
          </section>

          <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
            <h2 className="font-display text-xl font-semibold text-slate-900">
              Passenger Manifest ({travelers})
            </h2>

            {travelerDetails.map((traveler, idx) => (
              <div
                key={idx}
                className="p-4 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-12 gap-3 items-end"
              >
                <div className="sm:col-span-6">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Traveler {idx + 1} Full Name (as per Aadhaar / Passport) *
                  </label>
                  <input
                    type="text"
                    required
                    value={traveler.fullName}
                    onChange={(e) => updateTraveler(idx, { fullName: e.target.value })}
                    placeholder="e.g. Rohan Deshmukh"
                    className="w-full h-10 px-3 text-sm bg-white border border-slate-200 rounded-lg"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Age *</label>
                  <input
                    type="number"
                    min={1}
                    max={110}
                    required
                    value={traveler.age}
                    onChange={(e) => updateTraveler(idx, { age: Number(e.target.value) })}
                    className="w-full h-10 px-3 text-sm bg-white border border-slate-200 rounded-lg tabular-nums"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Gender</label>
                  <select
                    value={traveler.gender}
                    onChange={(e) =>
                      updateTraveler(idx, {
                        gender: e.target.value as TravelerInput['gender'],
                      })
                    }
                    className="w-full h-10 px-3 text-sm bg-white border border-slate-200 rounded-lg"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>
            ))}
          </section>

          <section className="bg-white border border-slate-200 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-xl font-semibold text-slate-900">
                Payment Method (Sandbox)
              </h2>
              <span className="text-xs text-slate-500">Razorpay-ready Indian checkout</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-5">
              {(
                [
                  { id: 'UPI', label: 'UPI / QR', icon: Smartphone },
                  { id: 'Card', label: 'Cards', icon: CreditCard },
                  { id: 'NetBanking', label: 'NetBanking', icon: Landmark },
                  { id: 'Wallet', label: 'Wallets', icon: Wallet },
                ] as const
              ).map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setPaymentMethod(id)}
                  className={`py-2.5 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer transition-colors ${
                    paymentMethod === id
                      ? 'bg-indigo-900 text-white border-indigo-900'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="h-3.5 w-3.5" />
                  <span>{label}</span>
                </button>
              ))}
            </div>

            {paymentMethod === 'UPI' && (
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <label className="block text-xs font-semibold text-slate-700">
                  Enter UPI ID (GPay, PhonePe, BHIM, Paytm)
                </label>
                <input
                  type="text"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  placeholder="yourname@okicici"
                  className="w-full h-11 px-3 text-sm font-mono bg-white border border-slate-200 rounded-lg"
                />
                <p className="text-xs text-slate-500">
                  Zero convenience fee surcharge on UPI sandbox verification.
                </p>
              </div>
            )}

            {paymentMethod === 'Card' && (
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    RuPay / Visa / Mastercard Number
                  </label>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    className="w-full h-10 px-3 text-sm font-mono bg-white border border-slate-200 rounded-lg tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Expiry</label>
                  <input
                    type="text"
                    value={cardExpiry}
                    onChange={(e) => setCardExpiry(e.target.value)}
                    className="w-full h-10 px-3 text-sm font-mono bg-white border border-slate-200 rounded-lg tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">CVV</label>
                  <input
                    type="password"
                    defaultValue="123"
                    maxLength={4}
                    className="w-full h-10 px-3 text-sm font-mono bg-white border border-slate-200 rounded-lg"
                  />
                </div>
              </div>
            )}

            {paymentMethod === 'NetBanking' && (
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Select Indian Bank
                </label>
                <select
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full h-10 px-3 text-sm bg-white border border-slate-200 rounded-lg"
                >
                  <option value="HDFC Bank">HDFC Bank</option>
                  <option value="ICICI Bank">ICICI Bank</option>
                  <option value="State Bank of India">State Bank of India (SBI)</option>
                  <option value="Axis Bank">Axis Bank</option>
                  <option value="Kotak Mahindra Bank">Kotak Mahindra Bank</option>
                </select>
              </div>
            )}

            {paymentMethod === 'Wallet' && (
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700">
                Instant authorization via PhonePe, Amazon Pay, or Paytm Wallet on booking confirmation.
              </div>
            )}

            {errorMsg && (
              <div
                role="alert"
                className="mt-4 p-3 rounded-lg bg-red-50 border border-red-200 text-xs font-medium text-red-700"
              >
                {errorMsg}
              </div>
            )}
          </section>
        </div>

        <aside className="lg:col-span-4 lg:sticky lg:top-24 space-y-5">
          <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
            <div className="pb-4 border-b border-slate-100">
              <p className="text-xs font-semibold text-indigo-900 mb-1">{offering.mode}</p>
              <h2 className="text-base font-semibold text-slate-900">{offering.title}</h2>
              <p className="text-xs text-slate-500 mt-1 tabular-nums">
                {formatDisplayDate(departureDate)} · {travelers}{' '}
                {travelers === 1 ? 'Traveler' : 'Travelers'} · {classTier}
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Promo Code (Try INDIA5 or YATRA1000)
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={promoInput}
                  onChange={(e) => setPromoInput(e.target.value.toUpperCase())}
                  placeholder="INDIA5"
                  className="flex-1 h-10 px-3 text-xs font-mono uppercase bg-slate-50 border border-slate-200 rounded-lg"
                />
                <button
                  type="button"
                  disabled={applyingPromo}
                  onClick={handleApplyPromo}
                  className="px-4 h-10 text-xs font-semibold bg-slate-900 text-white rounded-lg hover:bg-slate-800 cursor-pointer whitespace-nowrap shrink-0"
                >
                  Apply
                </button>
              </div>
              {quote.promoMessage && (
                <p
                  className={`text-xs mt-2 flex items-center gap-1.5 ${
                    quote.promoDiscount > 0 ? 'text-emerald-700' : 'text-amber-700'
                  }`}
                >
                  {quote.promoDiscount > 0 && <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />}
                  <span>{quote.promoMessage}</span>
                </p>
              )}
            </div>

            <div className="pt-4 border-t border-slate-100 space-y-2.5 text-xs text-slate-600 tabular-nums">
              <div className="flex justify-between">
                <span>
                  Base Fare ({quote.travelers} × {formatInr(quote.baseFarePerPerson)})
                </span>
                <span className="font-medium text-slate-900">{formatInr(quote.baseSubtotal)}</span>
              </div>
              {quote.addonsTotal > 0 && (
                <div className="flex justify-between">
                  <span>Add-on Upgrades</span>
                  <span className="font-medium text-slate-900">{formatInr(quote.addonsTotal)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Taxes &amp; 5% GST</span>
                <span className="font-medium text-slate-900">{formatInr(quote.gstAmount)}</span>
              </div>
              <div className="flex justify-between">
                <span>Convenience Fee</span>
                <span className="font-medium text-slate-900">{formatInr(quote.convenienceFee)}</span>
              </div>
              {quote.promoDiscount > 0 && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>Promo ({quote.promoCode})</span>
                  <span>-{formatInr(quote.promoDiscount)}</span>
                </div>
              )}
              <div className="pt-3 border-t border-slate-200 flex justify-between text-base font-semibold text-slate-900">
                <span>Grand Total</span>
                <span>{formatInr(quote.grandTotal)}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3.5 px-4 bg-indigo-900 hover:bg-indigo-800 disabled:opacity-60 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer"
            >
              {submitting ? 'Confirming PNR...' : `Pay ${formatInr(quote.grandTotal)} & Confirm`}
            </button>
          </div>
        </aside>
      </form>
    </div>
  );
}
