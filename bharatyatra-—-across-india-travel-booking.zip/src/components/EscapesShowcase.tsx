import { ArrowRight, Star } from 'lucide-react';
import { formatInr } from '../lib/format';
import type { TravelOffering } from '../types/travel';
import { TravelImage } from './TravelImage';

interface EscapesShowcaseProps {
  fiveDayEscapes: TravelOffering[];
  transitHighlights: TravelOffering[];
  onSelectOffering: (offering: TravelOffering) => void;
  onViewAllEscapes: () => void;
  onViewAllTransit: () => void;
}

export function EscapesShowcase({
  fiveDayEscapes,
  transitHighlights,
  onSelectOffering,
  onViewAllEscapes,
  onViewAllTransit,
}: EscapesShowcaseProps) {
  return (
    <div className="bg-slate-50">
      {/* Section 1: Top 5-Day Express Escapes */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 lg:py-18">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-indigo-900 mb-2">
              Curated 3 to 5-Day Itineraries
            </p>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-slate-900 tracking-tight">
              Top 5-Day India Getaways
            </h2>
          </div>
          <button
            type="button"
            onClick={onViewAllEscapes}
            className="inline-flex items-center gap-2 text-sm font-semibold text-indigo-900 hover:text-indigo-700 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span>View all packages</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
          {fiveDayEscapes.map((item) => (
            <article
              key={item.id}
              onClick={() => onSelectOffering(item)}
              className="group bg-white rounded-xl border border-slate-200 overflow-hidden hover:-translate-y-0.5 hover:shadow-md transition-all duration-150 cursor-pointer flex flex-col"
            >
              <div className="aspect-[4/3] overflow-hidden bg-slate-100">
                <TravelImage
                  imageKey={item.imageKey}
                  altOverride={item.title}
                  className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                />
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
                    <span className="font-mono font-medium text-slate-700">{item.destinationCode}</span>
                    <span aria-hidden="true">·</span>
                    <span>{item.region} India</span>
                    <span aria-hidden="true">·</span>
                    <span>{item.durationLabel}</span>
                  </div>

                  <h3 className="text-lg font-semibold text-slate-900 leading-snug mb-1.5 group-hover:text-indigo-900 transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-slate-600 line-clamp-2 mb-4">{item.subtitle}</p>
                </div>

                <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
                  <div>
                    <span className="text-xs text-slate-500 block">Per traveler</span>
                    <span className="text-lg font-semibold text-slate-900 tabular-nums">
                      {formatInr(item.basePriceInr)}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-700 tabular-nums">
                    <Star className="h-3.5 w-3.5 fill-amber-500 text-amber-500" />
                    <span className="font-semibold">{item.rating.toFixed(1)}</span>
                    <span className="text-slate-400">({item.reviewCount})</span>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Section 2: Point-to-Point Express Corridors */}
      <section className="bg-white border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 lg:py-18">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-indigo-900 mb-2">
                Intercity Transit Across India
              </p>
              <h2 className="font-display text-3xl sm:text-4xl font-semibold text-slate-900 tracking-tight">
                Vande Bharat, Flights &amp; Highway Cabs
              </h2>
            </div>
            <button
              type="button"
              onClick={onViewAllTransit}
              className="inline-flex items-center gap-2 text-sm font-semibold text-indigo-900 hover:text-indigo-700 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>Compare all routes</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {transitHighlights.map((route) => (
              <article
                key={route.id}
                onClick={() => onSelectOffering(route)}
                className="p-5 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white hover:-translate-y-0.5 hover:shadow-sm transition-all duration-150 cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-3">
                    <span className="font-medium text-indigo-900">{route.mode}</span>
                    <span className="font-mono tabular-nums">
                      {route.departureTime} – {route.arrivalTime}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 mb-2">
                    <span className="font-mono text-xl font-semibold text-slate-900">
                      {route.originCode}
                    </span>
                    <span className="flex-1 h-px bg-slate-300" aria-hidden="true" />
                    <span className="font-mono text-xl font-semibold text-slate-900">
                      {route.destinationCode}
                    </span>
                  </div>

                  <h3 className="text-base font-semibold text-slate-900 mb-1">{route.title}</h3>
                  <p className="text-xs text-slate-600 mb-4">{route.durationLabel}</p>
                </div>

                <div className="pt-3 border-t border-slate-200/80 flex items-center justify-between">
                  <span className="text-xs text-slate-500">
                    {route.freeCancellation ? 'Free cancellation' : 'Flexi reschedule'}
                  </span>
                  <span className="text-base font-semibold text-slate-900 tabular-nums">
                    {formatInr(route.basePriceInr)}
                  </span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
