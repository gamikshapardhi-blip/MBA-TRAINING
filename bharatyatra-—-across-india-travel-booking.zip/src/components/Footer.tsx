interface FooterProps {
  onNavigateEscapes: () => void;
  onNavigateTransit: () => void;
  onNavigateTrips: () => void;
}

export function Footer({
  onNavigateEscapes,
  onNavigateTransit,
  onNavigateTrips,
}: FooterProps) {
  return (
    <footer className="bg-white border-t border-slate-200 no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div>
          <span className="font-display text-lg font-semibold text-slate-900">BharatYatra</span>
          <p className="text-xs text-slate-500 mt-1">
            Curated journeys, Vande Bharat rail, flights, and heritage stays across India.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-6 text-xs font-medium text-slate-600">
          <button
            type="button"
            onClick={onNavigateEscapes}
            className="hover:text-slate-900 cursor-pointer"
          >
            5-Day Escapes
          </button>
          <button
            type="button"
            onClick={onNavigateTransit}
            className="hover:text-slate-900 cursor-pointer"
          >
            Flights &amp; Trains
          </button>
          <button
            type="button"
            onClick={onNavigateTrips}
            className="hover:text-slate-900 cursor-pointer"
          >
            My Trips
          </button>
          <span className="text-slate-400">Support: care@bharatyatra.in</span>
        </div>
      </div>
    </footer>
  );
}
