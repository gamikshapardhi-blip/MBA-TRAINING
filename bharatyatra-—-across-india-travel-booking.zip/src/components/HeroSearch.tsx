import { ArrowRightLeft, Calendar, MapPin, Search, Users } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { INDIAN_HUBS } from '../data/indiaSeed';
import type { ClassTier, IndianHub, SearchQuery, TravelCategory } from '../types/travel';
import { TravelImage } from './TravelImage';

interface HeroSearchProps {
  initialQuery: SearchQuery;
  onSearch: (query: SearchQuery) => void;
}

const CATEGORY_TABS: { id: TravelCategory; label: string }[] = [
  { id: 'packages', label: 'Packages' },
  { id: 'flights_trains', label: 'Flights & Trains' },
  { id: 'buses_cabs', label: 'Buses & Cabs' },
  { id: 'stays', label: 'Stays' },
];

export function HeroSearch({ initialQuery, onSearch }: HeroSearchProps) {
  const [category, setCategory] = useState<TravelCategory>(initialQuery.category);
  const [origin, setOrigin] = useState(initialQuery.origin);
  const [destination, setDestination] = useState(initialQuery.destination);
  const [departureDate, setDepartureDate] = useState(initialQuery.departureDate);
  const [returnDate, setReturnDate] = useState(initialQuery.returnDate);
  const [travelers, setTravelers] = useState(initialQuery.travelers);
  const [classTier, setClassTier] = useState<ClassTier>(initialQuery.classTier);

  const [activeField, setActiveField] = useState<'origin' | 'destination' | null>(null);
  const formRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (formRef.current && !formRef.current.contains(e.target as Node)) {
        setActiveField(null);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const filterHubs = (term: string): IndianHub[] => {
    const q = term.trim().toLowerCase();
    if (!q) return INDIAN_HUBS.slice(0, 6);
    return INDIAN_HUBS.filter(
      (h) =>
        h.city.toLowerCase().includes(q) ||
        h.code.toLowerCase().includes(q) ||
        h.state.toLowerCase().includes(q),
    ).slice(0, 6);
  };

  const handleSwap = () => {
    const prevOrigin = origin;
    setOrigin(destination);
    setDestination(prevOrigin);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setActiveField(null);
    onSearch({
      category,
      origin,
      destination,
      departureDate,
      returnDate,
      travelers,
      classTier,
    });
  };

  return (
    <section className="relative bg-slate-900">
      <div className="relative min-h-[540px] lg:min-h-[580px] flex items-center">
        <TravelImage
          imageKey="hero"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div
          className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/55 to-slate-950/40"
          aria-hidden="true"
        />

        <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 lg:py-20">
          <div className="max-w-2xl mb-8">
            <p className="text-xs font-medium tracking-wider uppercase text-amber-300 mb-3">
              Across 15+ Indian Regions · Instant PNR &amp; GST Invoices
            </p>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-[56px] font-semibold leading-[1.08] tracking-tight text-white mb-4">
              Every Indian journey, planned in minutes.
            </h1>
            <p className="text-base sm:text-lg text-slate-200 leading-relaxed max-w-xl">
              Compare curated 5-day escapes, Vande Bharat rail, nonstop domestic flights, Volvo coaches, and heritage havelis in one transparent INR checkout.
            </p>
          </div>

          <div
            ref={formRef}
            className="bg-white rounded-xl border border-slate-200 p-4 sm:p-6 shadow-lg"
          >
            <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-4 mb-5">
              {CATEGORY_TABS.map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setCategory(tab.id)}
                  className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    category === tab.id
                      ? 'bg-indigo-900 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
              {/* Origin */}
              <div className="md:col-span-3 relative">
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Origin City / Hub
                </label>
                <div className="relative flex items-center">
                  <MapPin className="h-4 w-4 text-slate-400 absolute left-3 pointer-events-none" />
                  <input
                    type="text"
                    value={origin}
                    onFocus={() => setActiveField('origin')}
                    onChange={(e) => {
                      setOrigin(e.target.value);
                      setActiveField('origin');
                    }}
                    placeholder="e.g. DEL or New Delhi"
                    className="w-full h-11 pl-9 pr-3 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-900 focus:bg-white"
                  />
                </div>
                {activeField === 'origin' && (
                  <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg z-30 max-h-60 overflow-y-auto">
                    {filterHubs(origin).map((hub) => (
                      <button
                        key={`origin-${hub.code}`}
                        type="button"
                        onClick={() => {
                          setOrigin(hub.city);
                          setActiveField(null);
                        }}
                        className="w-full px-3 py-2.5 text-left hover:bg-slate-50 flex items-center justify-between gap-2 border-b border-slate-100 last:border-0 cursor-pointer"
                      >
                        <div className="min-w-0">
                          <div className="text-sm font-medium text-slate-900 truncate">{hub.city}</div>
                          <div className="text-xs text-slate-500 truncate">{hub.hubName}</div>
                        </div>
                        <span className="font-mono text-xs font-medium text-indigo-900 shrink-0">
                          {hub.code}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Swap button on desktop */}
              <div className="hidden md:flex md:col-span-1 justify-center pb-1">
                <button
                  type="button"
                  onClick={handleSwap}
                  aria-label="Swap origin and destination"
                  className="h-9 w-9 rounded-lg border border-slate-200 flex items-center justify-center text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer"
                >
                  <ArrowRightLeft className="h-4 w-4" />
                </button>
              </div>

              {/* Destination */}
              <div className="md:col-span-3 relative">
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Destination
                </label>
                <div className="relative flex items-center">
                  <MapPin className="h-4 w-4 text-slate-400 absolute left-3 pointer-events-none" />
                  <input
                    type="text"
                    value={destination}
                    onFocus={() => setActiveField('destination')}
                    onChange={(e) => {
                      setDestination(e.target.value);
                      setActiveField('destination');
                    }}
                    placeholder="Jaipur, Kerala, Goa, Leh..."
                    className="w-full h-11 pl-9 pr-3 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-900 focus:bg-white"
                  />
                </div>
                {activeField === 'destination' && (
                  <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg z-30 max-h-60 overflow-y-auto">
                    {filterHubs(destination).map((hub) => (
                      <button
                        key={`dest-${hub.code}`}
                        type="button"
                        onClick={() => {
                          setDestination(hub.city);
                          setActiveField(null);
                        }}
                        className="w-full px-3 py-2.5 text-left hover:bg-slate-50 flex items-center justify-between gap-2 border-b border-slate-100 last:border-0 cursor-pointer"
                      >
                        <div className="min-w-0">
                          <div className="text-sm font-medium text-slate-900 truncate">{hub.city}</div>
                          <div className="text-xs text-slate-500 truncate">{hub.state}</div>
                        </div>
                        <span className="font-mono text-xs font-medium text-indigo-900 shrink-0">
                          {hub.code}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Dates */}
              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Departure
                </label>
                <div className="relative flex items-center">
                  <Calendar className="h-4 w-4 text-slate-400 absolute left-3 pointer-events-none" />
                  <input
                    type="date"
                    value={departureDate}
                    min="2026-11-20"
                    onChange={(e) => setDepartureDate(e.target.value)}
                    className="w-full h-11 pl-9 pr-2 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-900 focus:bg-white tabular-nums"
                  />
                </div>
              </div>

              {/* Travelers & Tier */}
              <div className="md:col-span-1">
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Guests
                </label>
                <div className="relative flex items-center">
                  <Users className="h-4 w-4 text-slate-400 absolute left-2.5 pointer-events-none" />
                  <select
                    value={travelers}
                    onChange={(e) => setTravelers(Number(e.target.value))}
                    className="w-full h-11 pl-8 pr-2 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-900 focus:bg-white tabular-nums"
                  >
                    {[1, 2, 3, 4, 5, 6].map((count) => (
                      <option key={count} value={count}>
                        {count}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Submit CTA */}
              <div className="md:col-span-2">
                <button
                  type="submit"
                  className="w-full h-11 px-4 bg-indigo-900 hover:bg-indigo-800 text-white text-sm font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Search className="h-4 w-4" />
                  <span>Search India</span>
                </button>
              </div>
            </form>

            <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
              <div className="flex flex-wrap items-center gap-4">
                <span className="font-medium text-slate-800">Comfort Tier:</span>
                {(['Standard', 'Comfort', 'Executive'] as ClassTier[]).map((tier) => (
                  <button
                    key={tier}
                    type="button"
                    onClick={() => setClassTier(tier)}
                    className={`cursor-pointer transition-colors whitespace-nowrap shrink-0 ${
                      classTier === tier
                        ? 'font-semibold text-indigo-900 underline underline-offset-4'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {tier}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-2">
                <label className="text-slate-500">Return:</label>
                <input
                  type="date"
                  value={returnDate}
                  min={departureDate}
                  onChange={(e) => setReturnDate(e.target.value)}
                  className="text-xs text-slate-800 bg-slate-50 border border-slate-200 rounded px-2 py-1 tabular-nums"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Full-width 4-column proof/trust strip below hero */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 grid grid-cols-2 lg:grid-cols-4 gap-6">
          <div>
            <p className="font-mono text-lg font-semibold text-slate-900 tabular-nums">15+ Hubs</p>
            <p className="text-xs text-slate-600 mt-0.5">DEL, BOM, BLR, GOI, COK, IXL &amp; more</p>
          </div>
          <div>
            <p className="font-mono text-lg font-semibold text-slate-900 tabular-nums">5% GST</p>
            <p className="text-xs text-slate-600 mt-0.5">Transparent fares with GSTIN tax invoice</p>
          </div>
          <div>
            <p className="font-mono text-lg font-semibold text-slate-900 tabular-nums">UPI &amp; Cards</p>
            <p className="text-xs text-slate-600 mt-0.5">Zero-markup INR checkout with INDIA5</p>
          </div>
          <div>
            <p className="font-mono text-lg font-semibold text-slate-900 tabular-nums">Instant PNR</p>
            <p className="text-xs text-slate-600 mt-0.5">One-click reschedule &amp; printable e-ticket</p>
          </div>
        </div>
      </div>
    </section>
  );
}
