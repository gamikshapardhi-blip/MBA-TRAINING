import { Calendar, CheckCircle2, Download, Printer, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { formatDisplayDate, formatInr } from '../lib/format';
import type { BookingRecord, BookingStatus, UserSession } from '../types/travel';
import { TravelImage } from './TravelImage';

interface MyTripsViewProps {
  justConfirmedPnr: string | null;
  user: UserSession | null;
  onExploreTrips: () => void;
}

export function MyTripsView({
  justConfirmedPnr,
  user,
  onExploreTrips,
}: MyTripsViewProps) {
  const [bookings, setBookings] = useState<BookingRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusTab, setStatusTab] = useState<BookingStatus>('Upcoming');
  const [ticketModal, setTicketModal] = useState<BookingRecord | null>(null);
  const [rescheduleTarget, setRescheduleTarget] = useState<BookingRecord | null>(null);
  const [newDate, setNewDate] = useState('');
  const [actionBusy, setActionBusy] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const loadBookings = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/bookings');
      if (res.ok) {
        const data = (await res.json()) as { bookings: BookingRecord[] };
        setBookings(data.bookings || []);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBookings();
  }, [justConfirmedPnr]);

  const handleCancel = async (pnrCode: string) => {
    setActionBusy(pnrCode);
    setActionError(null);
    try {
      const res = await fetch(`/api/bookings/${pnrCode}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'cancel' }),
      });
      const data = (await res.json()) as { booking?: BookingRecord; error?: string };
      if (!res.ok || !data.booking) {
        throw new Error(data.error || 'Could not cancel booking.');
      }
      setBookings((prev) => prev.map((b) => (b.pnrCode === pnrCode ? data.booking! : b)));
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Cancellation failed.');
    } finally {
      setActionBusy(null);
    }
  };

  const handleRescheduleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rescheduleTarget || !newDate) return;
    setActionBusy(rescheduleTarget.pnrCode);
    setActionError(null);
    try {
      const res = await fetch(`/api/bookings/${rescheduleTarget.pnrCode}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'reschedule', newDate }),
      });
      const data = (await res.json()) as { booking?: BookingRecord; error?: string };
      if (!res.ok || !data.booking) {
        throw new Error(data.error || 'Could not reschedule trip.');
      }
      setBookings((prev) =>
        prev.map((b) => (b.pnrCode === rescheduleTarget.pnrCode ? data.booking! : b)),
      );
      setRescheduleTarget(null);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Reschedule failed.');
    } finally {
      setActionBusy(null);
    }
  };

  const downloadTicketText = (booking: BookingRecord) => {
    const lines = [
      'BHARATYATRA E-TICKET & TAX INVOICE',
      '===================================',
      `PNR Confirmation: ${booking.pnrCode}`,
      `Status: ${booking.status}`,
      `Trip: ${booking.offeringTitle} (${booking.mode})`,
      `Route: ${booking.originCity} (${booking.originCode}) -> ${booking.destinationCity} (${booking.destinationCode})`,
      `Departure: ${formatDisplayDate(booking.departureDate)} at ${booking.departureTime}`,
      `Duration: ${booking.durationLabel}`,
      `Class Tier: ${booking.classTier}`,
      '',
      'PASSENGERS:',
      ...booking.travelerDetails.map(
        (t, idx) => `  ${idx + 1}. ${t.fullName} (${t.age} yrs, ${t.gender})`,
      ),
      '',
      'FARE SUMMARY (INR):',
      `  Base Subtotal: ${formatInr(booking.fare.baseSubtotal)}`,
      `  Upgrades: ${formatInr(booking.fare.addonsTotal)}`,
      `  Taxes & 5% GST: ${formatInr(booking.fare.gstAmount)}`,
      `  Convenience Fee: ${formatInr(booking.fare.convenienceFee)}`,
      `  Promo Discount: -${formatInr(booking.fare.promoDiscount)}`,
      `  TOTAL PAID (${booking.paymentMethod}): ${formatInr(booking.fare.grandTotal)}`,
      booking.gstin ? `  GSTIN: ${booking.gstin}` : '',
      '',
      `Contact: ${booking.contactEmail} | ${booking.contactPhone}`,
    ]
      .filter(Boolean)
      .join('\n');

    const blob = new Blob([lines], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${booking.pnrCode}-BharatYatra-Ticket.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const filteredBookings = bookings.filter((b) => b.status === statusTab);
  const confirmedBooking = justConfirmedPnr
    ? bookings.find((b) => b.pnrCode === justConfirmedPnr)
    : null;

  return (
    <div className="bg-slate-50 min-h-[calc(100vh-4rem)] py-10">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {confirmedBooking && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="h-6 w-6 text-emerald-700 shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-emerald-800">
                  Booking Confirmed
                </p>
                <h2 className="font-display text-xl font-semibold text-slate-900 mt-0.5">
                  PNR {confirmedBooking.pnrCode} — {confirmedBooking.offeringTitle}
                </h2>
                <p className="text-xs text-slate-600 mt-1">
                  E-ticket sent to {confirmedBooking.contactEmail} and {confirmedBooking.contactPhone}.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setTicketModal(confirmedBooking)}
              className="px-4 py-2.5 bg-indigo-900 text-white text-xs font-semibold rounded-lg hover:bg-indigo-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              View E-Ticket
            </button>
          </div>
        )}

        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 no-print">
          <div>
            <h1 className="font-display text-3xl font-semibold text-slate-900">
              {user ? `${user.name}'s Trips` : 'My Trips & Bookings'}
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Manage upcoming Indian itineraries, download GST e-tickets, or reschedule dates.
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-white border border-slate-200 rounded-lg self-start">
            {(['Upcoming', 'Completed', 'Cancelled'] as BookingStatus[]).map((tab) => {
              const count = bookings.filter((b) => b.status === tab).length;
              return (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setStatusTab(tab)}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    statusTab === tab
                      ? 'bg-indigo-900 text-white'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tab} ({count})
                </button>
              );
            })}
          </div>
        </div>

        {actionError && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 no-print">
            {actionError}
          </div>
        )}

        {loading ? (
          <div className="space-y-4">
            {[1, 2].map((n) => (
              <div key={n} className="bg-white border border-slate-200 rounded-xl p-6 animate-pulse h-40" />
            ))}
          </div>
        ) : filteredBookings.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-10 text-center no-print">
            <h3 className="text-lg font-semibold text-slate-900 mb-2">
              No {statusTab.toLowerCase()} bookings
            </h3>
            <p className="text-sm text-slate-600 mb-5">
              Ready to plan your next 5-day Indian getaway or express rail corridor?
            </p>
            <button
              type="button"
              onClick={onExploreTrips}
              className="px-5 py-2.5 bg-indigo-900 text-white text-sm font-semibold rounded-lg hover:bg-indigo-800 cursor-pointer"
            >
              Explore India Packages
            </button>
          </div>
        ) : (
          <div className="space-y-4 no-print">
            {filteredBookings.map((booking) => (
              <article
                key={booking.pnrCode}
                className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col md:flex-row"
              >
                <div className="md:w-52 aspect-[4/3] md:aspect-auto bg-slate-100 shrink-0">
                  <TravelImage
                    imageKey={booking.imageKey}
                    altOverride={booking.offeringTitle}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between gap-4">
                  <div>
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2 text-xs text-slate-500">
                        <span className="font-mono font-semibold text-indigo-900">
                          PNR {booking.pnrCode}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{booking.mode}</span>
                        <span aria-hidden="true">·</span>
                        <span>{booking.classTier}</span>
                      </div>
                      <span
                        className={`text-xs font-semibold ${
                          booking.status === 'Upcoming'
                            ? 'text-emerald-700'
                            : booking.status === 'Completed'
                              ? 'text-slate-600'
                              : 'text-red-700'
                        }`}
                      >
                        {booking.status}
                      </span>
                    </div>

                    <h3 className="text-lg font-semibold text-slate-900">{booking.offeringTitle}</h3>
                    <p className="text-xs text-slate-600 mt-1 tabular-nums">
                      {booking.originCity} ({booking.originCode}) → {booking.destinationCity} (
                      {booking.destinationCode}) · Departs {formatDisplayDate(booking.departureDate)}{' '}
                      at {booking.departureTime}
                    </p>
                    {booking.rescheduledFrom && (
                      <p className="text-[11px] text-amber-700 mt-1 tabular-nums">
                        Rescheduled from {formatDisplayDate(booking.rescheduledFrom)}
                      </p>
                    )}
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <span className="text-xs text-slate-500 block">
                        {booking.travelers} {booking.travelers === 1 ? 'Traveler' : 'Travelers'} ·{' '}
                        {booking.paymentMethod}
                      </span>
                      <span className="text-base font-semibold text-slate-900 tabular-nums">
                        {formatInr(booking.fare.grandTotal)}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setTicketModal(booking)}
                        className="px-3.5 py-2 text-xs font-semibold border border-slate-200 rounded-lg text-slate-800 hover:bg-slate-50 cursor-pointer"
                      >
                        E-Ticket
                      </button>

                      {booking.status === 'Upcoming' && (
                        <>
                          <button
                            type="button"
                            onClick={() => {
                              setRescheduleTarget(booking);
                              setNewDate(booking.departureDate);
                            }}
                            className="px-3.5 py-2 text-xs font-semibold border border-slate-200 rounded-lg text-slate-800 hover:bg-slate-50 cursor-pointer"
                          >
                            Reschedule
                          </button>
                          <button
                            type="button"
                            disabled={actionBusy === booking.pnrCode}
                            onClick={() => handleCancel(booking.pnrCode)}
                            className="px-3.5 py-2 text-xs font-semibold border border-red-200 rounded-lg text-red-700 hover:bg-red-50 cursor-pointer disabled:opacity-50"
                          >
                            {actionBusy === booking.pnrCode ? 'Cancelling...' : 'Cancel'}
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>

      {/* E-Ticket Modal */}
      {ticketModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl border border-slate-200 max-w-xl w-full p-6 sm:p-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-200">
              <div>
                <p className="font-mono text-xs font-semibold text-indigo-900">
                  BHARATYATRA E-TICKET · {ticketModal.pnrCode}
                </p>
                <h2 className="font-display text-2xl font-semibold text-slate-900 mt-1">
                  {ticketModal.offeringTitle}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setTicketModal(null)}
                className="h-8 w-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-600 hover:bg-slate-100 no-print cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="py-5 space-y-5 text-sm">
              <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-lg border border-slate-200">
                <div>
                  <span className="text-xs text-slate-500 block">Route</span>
                  <span className="font-mono font-semibold text-slate-900">
                    {ticketModal.originCode} → {ticketModal.destinationCode}
                  </span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 block">Departure</span>
                  <span className="font-semibold text-slate-900 tabular-nums">
                    {formatDisplayDate(ticketModal.departureDate)} · {ticketModal.departureTime}
                  </span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 block">Mode &amp; Tier</span>
                  <span className="text-slate-900">
                    {ticketModal.mode} · {ticketModal.classTier}
                  </span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 block">Status</span>
                  <span className="font-semibold text-slate-900">{ticketModal.status}</span>
                </div>
              </div>

              <div>
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
                  Passengers
                </h3>
                <ul className="divide-y divide-slate-100 border border-slate-200 rounded-lg">
                  {ticketModal.travelerDetails.map((t, i) => (
                    <li key={i} className="px-4 py-2.5 flex justify-between text-xs">
                      <span className="font-medium text-slate-900">{t.fullName}</span>
                      <span className="text-slate-500 tabular-nums">
                        {t.age} yrs · {t.gender}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-3 border-t border-slate-200 space-y-1.5 text-xs text-slate-600 tabular-nums">
                <div className="flex justify-between">
                  <span>Base Fare + Add-ons</span>
                  <span>
                    {formatInr(ticketModal.fare.baseSubtotal + ticketModal.fare.addonsTotal)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Taxes &amp; 5% GST</span>
                  <span>{formatInr(ticketModal.fare.gstAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Convenience Fee</span>
                  <span>{formatInr(ticketModal.fare.convenienceFee)}</span>
                </div>
                {ticketModal.fare.promoDiscount > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Promo ({ticketModal.fare.promoCode})</span>
                    <span>-{formatInr(ticketModal.fare.promoDiscount)}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-slate-200 flex justify-between text-sm font-semibold text-slate-900">
                  <span>Total Paid ({ticketModal.paymentMethod})</span>
                  <span>{formatInr(ticketModal.fare.grandTotal)}</span>
                </div>
                {ticketModal.gstin && (
                  <p className="text-[11px] text-slate-500 pt-1 font-mono">
                    Tax Invoice GSTIN: {ticketModal.gstin}
                  </p>
                )}
              </div>
            </div>

            <div className="flex flex-wrap gap-3 pt-4 border-t border-slate-200 no-print">
              <button
                type="button"
                onClick={() => window.print()}
                className="flex-1 py-2.5 px-4 bg-indigo-900 text-white text-xs font-semibold rounded-lg hover:bg-indigo-800 inline-flex items-center justify-center gap-2 cursor-pointer"
              >
                <Printer className="h-4 w-4" />
                <span>Print E-Ticket</span>
              </button>
              <button
                type="button"
                onClick={() => downloadTicketText(ticketModal)}
                className="flex-1 py-2.5 px-4 border border-slate-200 text-slate-800 text-xs font-semibold rounded-lg hover:bg-slate-50 inline-flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="h-4 w-4" />
                <span>Download Summary</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reschedule Modal */}
      {rescheduleTarget && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4 no-print">
          <form
            onSubmit={handleRescheduleSubmit}
            className="bg-white rounded-xl border border-slate-200 max-w-md w-full p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-semibold text-slate-900">
                Reschedule {rescheduleTarget.pnrCode}
              </h2>
              <button
                type="button"
                onClick={() => setRescheduleTarget(null)}
                className="h-8 w-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-600 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="text-xs text-slate-600">
              Select your new departure date for {rescheduleTarget.offeringTitle}.
            </p>
            <div className="relative flex items-center">
              <Calendar className="h-4 w-4 text-slate-400 absolute left-3 pointer-events-none" />
              <input
                type="date"
                required
                min="2026-11-20"
                value={newDate}
                onChange={(e) => setNewDate(e.target.value)}
                className="w-full h-11 pl-9 pr-3 text-sm bg-slate-50 border border-slate-200 rounded-lg tabular-nums"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setRescheduleTarget(null)}
                className="px-4 py-2 text-xs font-semibold border border-slate-200 rounded-lg text-slate-700 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={actionBusy === rescheduleTarget.pnrCode}
                className="px-4 py-2 text-xs font-semibold bg-indigo-900 text-white rounded-lg hover:bg-indigo-800 cursor-pointer"
              >
                Confirm New Date
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
