import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import type { UserSession } from '../types/travel';

export type AppView = 'home' | 'results' | 'detail' | 'checkout' | 'trips';

interface NavbarProps {
  activeView: AppView;
  onNavigateHome: () => void;
  onNavigateEscapes: () => void;
  onNavigateTransit: () => void;
  onNavigateTrips: () => void;
  user: UserSession | null;
  onOpenAuth: () => void;
  onSignOut: () => void;
}

export function Navbar({
  activeView,
  onNavigateHome,
  onNavigateEscapes,
  onNavigateTransit,
  onNavigateTrips,
  user,
  onOpenAuth,
  onSignOut,
}: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-200 no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <button
          type="button"
          onClick={onNavigateHome}
          className="font-display text-xl font-semibold tracking-tight text-slate-900 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-indigo-900"
        >
          BharatYatra
        </button>

        {/* Zone 2: 4 concise single-line nav links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
          <button
            type="button"
            onClick={onNavigateHome}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
              activeView === 'home'
                ? 'border-indigo-900 text-slate-900'
                : 'border-transparent hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            Explore
          </button>
          <button
            type="button"
            onClick={onNavigateEscapes}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
              activeView === 'results'
                ? 'border-indigo-900 text-slate-900'
                : 'border-transparent hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            5-Day Escapes
          </button>
          <button
            type="button"
            onClick={onNavigateTransit}
            className="whitespace-nowrap shrink-0 py-1 border-b-2 border-transparent hover:text-slate-900 hover:border-slate-300 transition-colors cursor-pointer"
          >
            Rail & Flights
          </button>
          <button
            type="button"
            onClick={onNavigateTrips}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
              activeView === 'trips'
                ? 'border-indigo-900 text-slate-900'
                : 'border-transparent hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            My Trips
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          {user ? (
            <button
              type="button"
              onClick={onSignOut}
              title={`Signed in as ${user.email}`}
              className="hidden sm:inline-flex items-center px-4 py-2 text-xs font-semibold text-slate-900 bg-slate-100 border border-slate-200 rounded-lg hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer max-w-[180px] truncate"
            >
              {user.name} · Sign Out
            </button>
          ) : (
            <button
              type="button"
              onClick={onOpenAuth}
              className="hidden sm:inline-flex items-center px-4 py-2 text-xs font-semibold text-white bg-indigo-900 rounded-lg hover:bg-indigo-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Sign In
            </button>
          )}

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
            className="md:hidden inline-flex items-center justify-center h-10 w-10 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-2">
          <button
            type="button"
            onClick={() => {
              setMobileOpen(false);
              onNavigateHome();
            }}
            className="block w-full text-left px-3 py-2.5 text-sm font-medium text-slate-800 rounded-lg hover:bg-slate-100"
          >
            Explore
          </button>
          <button
            type="button"
            onClick={() => {
              setMobileOpen(false);
              onNavigateEscapes();
            }}
            className="block w-full text-left px-3 py-2.5 text-sm font-medium text-slate-800 rounded-lg hover:bg-slate-100"
          >
            5-Day Escapes
          </button>
          <button
            type="button"
            onClick={() => {
              setMobileOpen(false);
              onNavigateTransit();
            }}
            className="block w-full text-left px-3 py-2.5 text-sm font-medium text-slate-800 rounded-lg hover:bg-slate-100"
          >
            Rail & Flights
          </button>
          <button
            type="button"
            onClick={() => {
              setMobileOpen(false);
              onNavigateTrips();
            }}
            className="block w-full text-left px-3 py-2.5 text-sm font-medium text-slate-800 rounded-lg hover:bg-slate-100"
          >
            My Trips
          </button>
          <div className="pt-2 border-t border-slate-100">
            {user ? (
              <button
                type="button"
                onClick={() => {
                  setMobileOpen(false);
                  onSignOut();
                }}
                className="w-full px-4 py-2.5 text-xs font-semibold text-slate-900 bg-slate-100 rounded-lg"
              >
                {user.name} · Sign Out
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setMobileOpen(false);
                  onOpenAuth();
                }}
                className="w-full px-4 py-2.5 text-xs font-semibold text-white bg-indigo-900 rounded-lg"
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
