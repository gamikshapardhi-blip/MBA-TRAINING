import { ArrowLeft, Calendar, Check, Clock, ShieldCheck, Star, Users } from 'lucide-react';
import { useEffect, useState } from 'react';
import { addDaysIso, formatDisplayDate, formatInr } from '../lib/format';
import type { ClassTier, QuoteBreakdown, TravelOffering } from '../types/travel';
import { TravelImage } from './TravelImage';

interface OfferingDetailViewProps {
  offering: TravelOffering;
  initialDepartureDate: string;
  initialTravelers: number;
  initialClassTier: ClassTier;
  onBack: () => void;
  onProceedCheckout: (config: {
    offering: TravelOffering;
    departureDate: string;
    returnDate: string;
    travelers: number;
    classTier: ClassTier;
    selectedAddonIds: string[];
    quote: QuoteBreakdown;
  }) => void;
}

export function OfferingDetailView({
  offering,
  initialDepartureDate,
  initialTravelers,
  initialClassTier,
  onBack,
  onProceedCheckout,
}: OfferingDetailViewProps) {
  const [departureDate, setDepartureDate] = useState(initialDepartureDate);
  const [travelers, setTravelers] = useState(initialTravelers);
  const [classTier, setClassTier] = useState<ClassTier>(initialClassTier);
  const [selectedAddonIds, setSelectedAddonIds] = useState<string[]>([]);
  const [quote, setQuote] = useState<QuoteBreakdown | null>(null);
  const [loadingQuote, setLoadingQuote] = useState(true);

  const computedReturnDate = addDaysIso(
    departureDate,
    Math.max(0, offering.durationDays - 1),
  );

  useEffect(() => {
    let active = true;
    const fetchQuote = async () => {
      setLoadingQuote(true);
      try {
        const res = await fetch('/api/quote', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            offeringId: offering.id,
            travelers,
            classTier,
            selectedAddonIds,
          }),
        });
        if (!res.ok) throw new Error('Quote calculation failed');
        const data = (await res.json()) as { quote: QuoteBreakdown };
        if (active) setQuote(data.quote);
      } finally {
        if (active) setLoadingQuote(false);
      }
    };
    fetchQuote();
    return () => {
      active = false;
    };
  }, [offering.id, travelers, classTier, selectedAddonIds]);

  const toggleAddon = (id: string) => {
    setSelectedAddonIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id],
    );
  };

  return (
    <div className="bg-slate-50 min-h-[calc(100vh-4rem)] pb-24 lg:pb-14">
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-3">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 hover:text-slate-900 cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to results</span>
          </button>
          <span className="text-slate-300" aria-hidden="true">/</span>
          <span className="text-xs text-slate-500 truncate">{offering.title}</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Visual, Itinerary, Inclusions, Add-ons */}
        <div className="lg:col-span-8 space-y-8">
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="aspect-[16/9] bg-slate-100 overflow-hidden">
              <TravelImage
                imageKey={offering.imageKey}
                altOverride={offering.title}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="p-6 sm:p-8">
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mb-3">
                <span className="font-semibold text-indigo-900">{offering.mode}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono text-slate-700">
                  {offering.originCode} → {offering.destinationCode}
                </span>
                <span aria-hidden="true">·</span>
                <span>{offering.durationLabel}</span>
                <span aria-hidden="true">·</span>
                <span className="inline-flex items-center gap-1 text-slate-700 tabular-nums">
                  <Star className="h-3.5 w-3.5 fill-amber-500 text-amber-500" />
                  <span className="font-semibold">{offering.rating.toFixed(1)}</span>
                  <span className="text-slate-400">({offering.reviewCount} reviews)</span>
                </span>
              </div>

              <h1 className="font-display text-3xl sm:text-4xl font-semibold text-slate-900 tracking-tight mb-2">
                {offering.title}
              </h1>
              <p className="text-base text-slate-600 mb-6">{offering.subtitle}</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-5 border-t border-slate-100">
                {offering.inclusions.map((inc) => (
                  <div key={inc} className="flex items-center gap-2.5 text-sm text-slate-700">
                    <Check className="h-4 w-4 text-emerald-700 shrink-0" />
                    <span>{inc}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Day-by-Day Itinerary / Route Stages */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
            <h2 className="font-display text-2xl font-semibold text-slate-900 mb-6">
              {offering.category === 'packages' ? 'Day-by-Day Itinerary' : 'Route & Schedule Timeline'}
            </h2>

            <div className="space-y-6">
              {offering.itinerary.map((step, index) => (
                <div
                  key={`${step.dayOrStage}-${index}`}
                  className="flex gap-4 pb-6 border-b border-slate-100 last:border-0 last:pb-0"
                >
                  <div className="w-20 shrink-0 pt-0.5">
                    <span className="font-mono text-xs font-semibold text-indigo-900 uppercase">
                      {step.dayOrStage}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                      <h3 className="text-base font-semibold text-slate-900">{step.title}</h3>
                      <span className="text-xs text-slate-500">{step.location}</span>
                    </div>
                    <p className="text-sm text-slate-600 leading-relaxed mb-2">{step.summary}</p>
                    <p className="text-xs font-medium text-slate-800">
                      Highlight: {step.highlight}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Interactive Add-ons */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
            <h2 className="font-display text-2xl font-semibold text-slate-900 mb-2">
              Customize Your Trip
            </h2>
            <p className="text-sm text-slate-600 mb-6">
              Optional upgrades calculated live in your Indian Rupee summary.
            </p>

            <div className="space-y-3">
              {offering.addons.map((addon) => {
                const active = selectedAddonIds.includes(addon.id);
                return (
                  <label
                    key={addon.id}
                    className={`flex items-start justify-between gap-4 p-4 rounded-xl border transition-colors cursor-pointer ${
                      active
                        ? 'border-indigo-900 bg-indigo-50/40'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        checked={active}
                        onChange={() => toggleAddon(addon.id)}
                        className="mt-1 h-4 w-4 accent-indigo-900 rounded"
                      />
                      <div>
                        <span className="block text-sm font-semibold text-slate-900">
                          {addon.name}
                        </span>
                        <span className="block text-xs text-slate-600 mt-0.5">
                          {addon.description}
                        </span>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="text-sm font-semibold text-slate-900 tabular-nums">
                        +{formatInr(addon.priceInr)}
                      </span>
                      <span className="block text-[11px] text-slate-500">
                        {addon.perTraveler ? 'per traveler' : 'per booking'}
                      </span>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Sticky Live Price Summary */}
        <aside className="lg:col-span-4 lg:sticky lg:top-24">
          <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
            <div className="pb-4 border-b border-slate-100">
              <span className="text-xs text-slate-500 block">Fare Summary</span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="font-display text-3xl font-semibold text-slate-900 tabular-nums">
                  {quote ? formatInr(quote.grandTotal) : formatInr(offering.basePriceInr)}
                </span>
                <span className="text-xs text-slate-500">incl. 5% GST</span>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Departure Date
                </label>
                <div className="relative flex items-center">
                  <Calendar className="h-4 w-4 text-slate-400 absolute left-3 pointer-events-none" />
                  <input
                    type="date"
                    value={departureDate}
                    min="2026-11-20"
                    onChange={(e) => setDepartureDate(e.target.value)}
                    className="w-full h-10 pl-9 pr-3 text-sm bg-slate-50 border border-slate-200 rounded-lg tabular-nums"
                  />
                </div>
                {offering.durationDays > 1 && (
                  <p className="text-[11px] text-slate-500 mt-1 tabular-nums">
                    Return on {formatDisplayDate(computedReturnDate)}
                  </p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Travelers
                  </label>
                  <div className="relative flex items-center">
                    <Users className="h-4 w-4 text-slate-400 absolute left-3 pointer-events-none" />
                    <select
                      value={travelers}
                      onChange={(e) => setTravelers(Number(e.target.value))}
                      className="w-full h-10 pl-9 pr-2 text-sm bg-slate-50 border border-slate-200 rounded-lg tabular-nums"
                    >
                      {[1, 2, 3, 4, 5, 6].map((n) => (
                        <option key={n} value={n}>
                          {n} {n === 1 ? 'Guest' : 'Guests'}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Class Tier
                  </label>
                  <select
                    value={classTier}
                    onChange={(e) => setClassTier(e.target.value as ClassTier)}
                    className="w-full h-10 px-3 text-sm bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    <option value="Standard">Standard</option>
                    <option value="Comfort">Comfort (+20%)</option>
                    <option value="Executive">Executive (+45%)</option>
                  </select>
                </div>
              </div>
            </div>

            {quote && (
              <div className="pt-4 border-t border-slate-100 space-y-2.5 text-xs text-slate-600 tabular-nums">
                <div className="flex justify-between">
                  <span>
                    Base Fare ({quote.travelers} × {formatInr(quote.baseFarePerPerson)})
                  </span>
                  <span className="font-medium text-slate-900">{formatInr(quote.baseSubtotal)}</span>
                </div>
                {quote.addonsTotal > 0 && (
                  <div className="flex justify-between">
                    <span>Selected Upgrades</span>
                    <span className="font-medium text-slate-900">{formatInr(quote.addonsTotal)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Taxes &amp; 5% GST</span>
                  <span className="font-medium text-slate-900">{formatInr(quote.gstAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Convenience Fee</span>
                  <span className="font-medium text-slate-900">{formatInr(quote.convenienceFee)}</span>
                </div>
                <div className="pt-2 border-t border-slate-100 flex justify-between text-sm font-semibold text-slate-900">
                  <span>Total Payable</span>
                  <span>{formatInr(quote.grandTotal)}</span>
                </div>
              </div>
            )}

            <button
              type="button"
              disabled={loadingQuote || !quote}
              onClick={() => {
                if (quote) {
                  onProceedCheckout({
                    offering,
                    departureDate,
                    returnDate: computedReturnDate,
                    travelers,
                    classTier,
                    selectedAddonIds,
                    quote,
                  });
                }
              }}
              className="w-full py-3 px-4 bg-indigo-900 hover:bg-indigo-800 disabled:opacity-60 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer"
            >
              {loadingQuote ? 'Calculating Fare...' : 'Proceed to Checkout'}
            </button>

            <div className="flex items-start gap-2 text-xs text-slate-500 pt-1">
              <ShieldCheck className="h-4 w-4 text-emerald-700 shrink-0 mt-0.5" />
              <span>{offering.cancellationPolicy}</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <Clock className="h-4 w-4 text-slate-400 shrink-0" />
              <span className="tabular-nums">
                Departure {offering.departureTime} · Arrival {offering.arrivalTime}
              </span>
            </div>
          </div>
        </aside>
      </div>

      {/* Compact Mobile Bottom CTA Bar (strictly < 15% vh) */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white border-t border-slate-200 px-4 py-2.5 flex items-center justify-between gap-4 shadow-md">
        <div>
          <span className="text-[11px] text-slate-500 block">Total incl. GST</span>
          <span className="text-lg font-semibold text-slate-900 tabular-nums">
            {quote ? formatInr(quote.grandTotal) : formatInr(offering.basePriceInr)}
          </span>
        </div>
        <button
          type="button"
          disabled={loadingQuote || !quote}
          onClick={() => {
            if (quote) {
              onProceedCheckout({
                offering,
                departureDate,
                returnDate: computedReturnDate,
                travelers,
                classTier,
                selectedAddonIds,
                quote,
              });
            }
          }}
          className="px-5 py-2.5 bg-indigo-900 text-white text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
        >
          Proceed to Checkout
        </button>
      </div>
    </div>
  );
}
