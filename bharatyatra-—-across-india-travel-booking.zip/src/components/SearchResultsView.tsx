import { ArrowLeft, Check, Filter, RotateCcw, Star } from 'lucide-react';
import { useEffect, useState } from 'react';
import { formatDisplayDate, formatInr } from '../lib/format';
import type {
  DepartureWindow,
  SearchQuery,
  TransportMode,
  TravelCategory,
  TravelOffering,
} from '../types/travel';
import { TravelImage } from './TravelImage';

interface SearchResultsViewProps {
  query: SearchQuery;
  fiveDayOnlyInitial?: boolean;
  onUpdateQuery: (next: SearchQuery) => void;
  onSelectOffering: (offering: TravelOffering) => void;
  onBackHome: () => void;
}

const MODE_OPTIONS: { value: string; label: string }[] = [
  { value: 'all', label: 'All Modes' },
  { value: 'Package', label: 'Curated Packages' },
  { value: 'Flight', label: 'Flights' },
  { value: 'Vande Bharat', label: 'Vande Bharat Rail' },
  { value: 'Volvo Bus', label: 'Volvo Buses' },
  { value: 'Intercity Cab', label: 'Intercity Cabs' },
  { value: 'Heritage Stay', label: 'Heritage Stays' },
];

export function SearchResultsView({
  query,
  fiveDayOnlyInitial = false,
  onUpdateQuery,
  onSelectOffering,
  onBackHome,
}: SearchResultsViewProps) {
  const [category, setCategory] = useState<TravelCategory | 'all'>(query.category);
  const [maxPrice, setMaxPrice] = useState<number>(35000);
  const [maxDurationDays, setMaxDurationDays] = useState<number>(0);
  const [selectedMode, setSelectedMode] = useState<string>('all');
  const [departureSlot, setDepartureSlot] = useState<DepartureWindow | 'all'>('all');
  const [minRating, setMinRating] = useState<number>(0);
  const [freeCancellation, setFreeCancellation] = useState<boolean>(false);
  const [fiveDayOnly, setFiveDayOnly] = useState<boolean>(fiveDayOnlyInitial);
  const [sort, setSort] = useState<string>('recommended');
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  const [results, setResults] = useState<TravelOffering[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setCategory(query.category);
  }, [query.category]);

  useEffect(() => {
    setFiveDayOnly(fiveDayOnlyInitial);
    if (fiveDayOnlyInitial) {
      setCategory('packages');
    }
  }, [fiveDayOnlyInitial]);

  useEffect(() => {
    let active = true;
    const fetchOfferings = async () => {
      setLoading(true);
      setError(null);
      try {
        const params = new URLSearchParams();
        if (category !== 'all') params.set('category', category);
        if (query.origin.trim()) params.set('origin', query.origin.trim());
        if (query.destination.trim()) params.set('destination', query.destination.trim());
        if (selectedMode !== 'all') params.set('mode', selectedMode);
        if (departureSlot !== 'all') params.set('departureSlot', departureSlot);
        if (maxPrice < 35000) params.set('maxPrice', String(maxPrice));
        if (maxDurationDays > 0) params.set('maxDurationDays', String(maxDurationDays));
        if (minRating > 0) params.set('minRating', String(minRating));
        if (freeCancellation) params.set('freeCancellation', 'true');
        if (fiveDayOnly) params.set('fiveDayOnly', 'true');
        params.set('sort', sort);

        const res = await fetch(`/api/offerings?${params.toString()}`);
        if (!res.ok) throw new Error('Unable to load travel options');
        const data = (await res.json()) as { offerings: TravelOffering[] };
        if (active) {
          setResults(data.offerings || []);
        }
      } catch (err) {
        if (active) {
          setError(err instanceof Error ? err.message : 'Something went wrong loading trips.');
        }
      } finally {
        if (active) setLoading(false);
      }
    };

    fetchOfferings();
    return () => {
      active = false;
    };
  }, [
    category,
    query.origin,
    query.destination,
    selectedMode,
    departureSlot,
    maxPrice,
    maxDurationDays,
    minRating,
    freeCancellation,
    fiveDayOnly,
    sort,
  ]);

  const resetAllFilters = () => {
    setCategory('all');
    setMaxPrice(35000);
    setMaxDurationDays(0);
    setSelectedMode('all');
    setDepartureSlot('all');
    setMinRating(0);
    setFreeCancellation(false);
    setFiveDayOnly(false);
    onUpdateQuery({ ...query, origin: '', destination: '' });
  };

  return (
    <div className="bg-slate-50 min-h-[calc(100vh-4rem)]">
      {/* Search summary bar */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBackHome}
              className="h-9 w-9 rounded-lg border border-slate-200 flex items-center justify-center text-slate-700 hover:bg-slate-100 cursor-pointer shrink-0"
              aria-label="Back to home"
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
            <div>
              <h1 className="font-display text-2xl font-semibold text-slate-900">
                {query.destination
                  ? `Trips to ${query.destination}`
                  : fiveDayOnly
                    ? 'Top 5-Day India Escapes'
                    : 'Explore Travel Across India'}
              </h1>
              <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
                {query.origin ? `From ${query.origin} · ` : ''}
                {formatDisplayDate(query.departureDate)} · {query.travelers}{' '}
                {query.travelers === 1 ? 'Traveler' : 'Travelers'} · {query.classTier}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {(
              [
                { id: 'all', label: 'All' },
                { id: 'packages', label: 'Packages' },
                { id: 'flights_trains', label: 'Flights & Trains' },
                { id: 'buses_cabs', label: 'Buses & Cabs' },
                { id: 'stays', label: 'Stays' },
              ] as { id: TravelCategory | 'all'; label: string }[]
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setCategory(tab.id);
                  if (tab.id !== 'packages') setFiveDayOnly(false);
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  category === tab.id
                    ? 'bg-indigo-900 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-5 lg:hidden">
          <button
            type="button"
            onClick={() => setMobileFiltersOpen((prev) => !prev)}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold bg-white border border-slate-200 rounded-lg text-slate-800 cursor-pointer"
          >
            <Filter className="h-3.5 w-3.5" />
            <span>{mobileFiltersOpen ? 'Hide Filters' : 'Filters'}</span>
          </button>

          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            aria-label="Sort results"
            className="px-3 py-2 text-xs font-medium bg-white border border-slate-200 rounded-lg text-slate-800"
          >
            <option value="recommended">Sort: Recommended</option>
            <option value="price_asc">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="fastest">Fastest Duration</option>
            <option value="rating">Highest Rated</option>
          </select>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Sidebar Filters */}
          <aside
            className={`lg:col-span-3 bg-white border border-slate-200 rounded-xl p-5 space-y-6 ${
              mobileFiltersOpen ? 'block' : 'hidden lg:block'
            }`}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h2 className="text-sm font-semibold text-slate-900 font-sans">Filters</h2>
              <button
                type="button"
                onClick={resetAllFilters}
                className="inline-flex items-center gap-1 text-xs font-medium text-indigo-900 hover:text-indigo-700 cursor-pointer"
              >
                <RotateCcw className="h-3 w-3" />
                <span>Reset</span>
              </button>
            </div>

            {/* Price Ceiling */}
            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-semibold text-slate-700">Max Price / Person</span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  {maxPrice >= 35000 ? 'Any' : formatInr(maxPrice)}
                </span>
              </div>
              <input
                type="range"
                min={2000}
                max={35000}
                step={1000}
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full accent-indigo-900 cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-slate-400 tabular-nums mt-1">
                <span>₹2,000</span>
                <span>₹35,000+</span>
              </div>
            </div>

            {/* Transport Mode */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-2">
                Transport / Experience Mode
              </label>
              <select
                value={selectedMode}
                onChange={(e) => setSelectedMode(e.target.value as TransportMode | 'all')}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
              >
                {MODE_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Duration */}
            <div>
              <span className="block text-xs font-semibold text-slate-700 mb-2">Duration</span>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { value: 0, label: 'Any' },
                  { value: 1, label: 'Same Day' },
                  { value: 4, label: 'Up to 4 Days' },
                  { value: 5, label: '5 Days' },
                ].map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setMaxDurationDays(opt.value)}
                    className={`px-2.5 py-1.5 text-xs rounded-lg border text-center cursor-pointer transition-colors ${
                      maxDurationDays === opt.value
                        ? 'bg-indigo-900 text-white border-indigo-900'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Departure Time */}
            <div>
              <span className="block text-xs font-semibold text-slate-700 mb-2">
                Departure Window
              </span>
              <div className="grid grid-cols-2 gap-2">
                {(
                  [
                    { value: 'all', label: 'Any Time' },
                    { value: 'morning', label: 'Morning' },
                    { value: 'afternoon', label: 'Afternoon' },
                    { value: 'evening', label: 'Evening / Night' },
                  ] as const
                ).map((slot) => (
                  <button
                    key={slot.value}
                    type="button"
                    onClick={() =>
                      setDepartureSlot(
                        slot.value === 'evening' ? 'evening' : (slot.value as DepartureWindow | 'all'),
                      )
                    }
                    className={`px-2.5 py-1.5 text-xs rounded-lg border text-center cursor-pointer transition-colors ${
                      departureSlot === slot.value
                        ? 'bg-indigo-900 text-white border-indigo-900'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {slot.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Rating & Toggles */}
            <div className="space-y-3 pt-2 border-t border-slate-100">
              <label className="flex items-center justify-between text-xs text-slate-700 cursor-pointer">
                <span>Free Cancellation Only</span>
                <input
                  type="checkbox"
                  checked={freeCancellation}
                  onChange={(e) => setFreeCancellation(e.target.checked)}
                  className="h-4 w-4 accent-indigo-900 rounded"
                />
              </label>

              <label className="flex items-center justify-between text-xs text-slate-700 cursor-pointer">
                <span>4.8+ Top Rated</span>
                <input
                  type="checkbox"
                  checked={minRating >= 4.8}
                  onChange={(e) => setMinRating(e.target.checked ? 4.8 : 0)}
                  className="h-4 w-4 accent-indigo-900 rounded"
                />
              </label>

              <label className="flex items-center justify-between text-xs text-slate-700 cursor-pointer">
                <span>5-Day Express Escapes</span>
                <input
                  type="checkbox"
                  checked={fiveDayOnly}
                  onChange={(e) => setFiveDayOnly(e.target.checked)}
                  className="h-4 w-4 accent-indigo-900 rounded"
                />
              </label>
            </div>
          </aside>

          {/* Main Results Column */}
          <div className="lg:col-span-9 space-y-5">
            <div className="hidden lg:flex items-center justify-between">
              <p className="text-sm text-slate-600 tabular-nums">
                Showing <span className="font-semibold text-slate-900">{results.length}</span>{' '}
                verified Indian travel options
              </p>

              <select
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                aria-label="Sort results"
                className="px-3.5 py-2 text-xs font-medium bg-white border border-slate-200 rounded-lg text-slate-800 cursor-pointer"
              >
                <option value="recommended">Sort: Recommended</option>
                <option value="price_asc">Price: Low to High</option>
                <option value="price_desc">Price: High to Low</option>
                <option value="fastest">Fastest Duration</option>
                <option value="rating">Highest Rated</option>
              </select>
            </div>

            {loading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((n) => (
                  <div
                    key={n}
                    className="bg-white border border-slate-200 rounded-xl p-5 animate-pulse flex flex-col sm:flex-row gap-5"
                  >
                    <div className="w-full sm:w-56 aspect-[4/3] bg-slate-200 rounded-lg shrink-0" />
                    <div className="flex-1 space-y-3 py-1">
                      <div className="h-3 bg-slate-200 rounded w-1/3" />
                      <div className="h-5 bg-slate-200 rounded w-2/3" />
                      <div className="h-4 bg-slate-200 rounded w-1/2" />
                      <div className="h-8 bg-slate-200 rounded w-1/4 mt-4" />
                    </div>
                  </div>
                ))}
              </div>
            ) : error ? (
              <div className="bg-white border border-red-200 rounded-xl p-8 text-center">
                <p className="text-sm font-medium text-red-700 mb-3">{error}</p>
                <button
                  type="button"
                  onClick={resetAllFilters}
                  className="px-4 py-2 text-xs font-semibold bg-indigo-900 text-white rounded-lg cursor-pointer"
                >
                  Retry Search
                </button>
              </div>
            ) : results.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-xl p-10 text-center">
                <h3 className="text-lg font-semibold text-slate-900 mb-2">
                  No matching routes or packages found
                </h3>
                <p className="text-sm text-slate-600 max-w-md mx-auto mb-6">
                  Try clearing your origin/destination filter or widening your INR budget ceiling to view all available Indian routes.
                </p>
                <button
                  type="button"
                  onClick={resetAllFilters}
                  className="px-5 py-2.5 text-sm font-semibold bg-indigo-900 text-white rounded-lg hover:bg-indigo-800 transition-colors cursor-pointer"
                >
                  Show All Indian Trips
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {results.map((item) => (
                  <article
                    key={item.id}
                    onClick={() => onSelectOffering(item)}
                    className="group bg-white border border-slate-200 rounded-xl overflow-hidden hover:-translate-y-0.5 hover:shadow-md transition-all duration-150 cursor-pointer flex flex-col sm:flex-row"
                  >
                    <div className="sm:w-64 aspect-[4/3] sm:aspect-auto bg-slate-100 shrink-0 overflow-hidden">
                      <TravelImage
                        imageKey={item.imageKey}
                        altOverride={item.title}
                        className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                      />
                    </div>

                    <div className="p-5 flex-1 flex flex-col justify-between gap-4">
                      <div>
                        <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                          <div className="flex items-center gap-2 text-xs text-slate-500">
                            <span className="font-semibold text-indigo-900">{item.mode}</span>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono text-slate-700">
                              {item.originCode} → {item.destinationCode}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span>{item.durationLabel}</span>
                          </div>

                          <div className="flex items-center gap-1 text-xs text-slate-700 tabular-nums">
                            <Star className="h-3.5 w-3.5 fill-amber-500 text-amber-500" />
                            <span className="font-semibold">{item.rating.toFixed(1)}</span>
                            <span className="text-slate-400">({item.reviewCount})</span>
                          </div>
                        </div>

                        <h3 className="text-lg font-semibold text-slate-900 group-hover:text-indigo-900 transition-colors">
                          {item.title}
                        </h3>
                        <p className="text-sm text-slate-600 mt-1">{item.subtitle}</p>

                        <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600">
                          {item.inclusions.slice(0, 3).map((inc) => (
                            <span key={inc} className="inline-flex items-center gap-1">
                              <Check className="h-3.5 w-3.5 text-emerald-700" />
                              <span>{inc}</span>
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-4">
                        <span className="text-xs text-slate-500">
                          {item.freeCancellation ? 'Free cancellation available' : item.cancellationPolicy}
                        </span>
                        <div className="flex items-center gap-4 shrink-0">
                          <div className="text-right">
                            <span className="text-[11px] text-slate-500 block">Starting from</span>
                            <span className="text-lg font-semibold text-slate-900 tabular-nums">
                              {formatInr(item.basePriceInr)}
                            </span>
                          </div>
                          <span className="px-4 py-2 text-xs font-semibold bg-indigo-900 text-white rounded-lg group-hover:bg-indigo-800 transition-colors whitespace-nowrap">
                            Select
                          </span>
                        </div>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
