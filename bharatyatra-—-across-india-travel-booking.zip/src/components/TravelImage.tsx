import { useState } from 'react';
import { Compass } from 'lucide-react';
import { MEDIA_ASSETS } from '../lib/media';
import type { ImageKey } from '../types/travel';

interface TravelImageProps {
  imageKey: ImageKey;
  altOverride?: string;
  className?: string;
}

export function TravelImage({ imageKey, altOverride, className = '' }: TravelImageProps) {
  const [failed, setFailed] = useState(false);
  const asset = MEDIA_ASSETS[imageKey] || MEDIA_ASSETS.hero;

  if (failed) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br ${asset.gradientFallback} text-white/90 ${className}`}
        role="img"
        aria-label={altOverride || asset.alt}
      >
        <Compass className="h-8 w-8 mb-2 opacity-80" strokeWidth={1.5} />
        <span className="text-xs font-medium tracking-wide px-4 text-center opacity-90">
          {altOverride || asset.alt}
        </span>
      </div>
    );
  }

  return (
    <img
      src={asset.src}
      alt={altOverride || asset.alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}
