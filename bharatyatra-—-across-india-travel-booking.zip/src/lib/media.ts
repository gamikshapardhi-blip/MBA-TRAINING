import type { ImageKey } from '../types/travel';

export interface MediaAsset {
  src: string;
  alt: string;
  gradientFallback: string;
}

export const MEDIA_ASSETS: Record<ImageKey, MediaAsset> = {
  hero: {
    src: '/src/assets/images/hero_india_journey_1795244385529.jpg',
    alt: 'Lake Pichola and carved sandstone arches in Udaipur, Rajasthan at golden hour',
    gradientFallback: 'from-indigo-950 via-slate-900 to-amber-900',
  },
  kerala: {
    src: '/src/assets/images/dest_kerala_backwaters_1795244385731.jpg',
    alt: 'Traditional kettuvallam houseboat gliding across emerald Kerala backwaters at sunrise',
    gradientFallback: 'from-emerald-950 via-teal-900 to-slate-900',
  },
  ladakh: {
    src: '/src/assets/images/dest_ladakh_expedition_1795244385609.jpg',
    alt: 'Turquoise Pangong Tso lake framed by ochre Himalayan peaks in Ladakh',
    gradientFallback: 'from-sky-950 via-indigo-900 to-slate-900',
  },
  rajasthan: {
    src: '/src/assets/images/dest_rajasthan_heritage_1795244385848.jpg',
    alt: 'Amber Fort sandstone ramparts and stepwell in Jaipur, Rajasthan',
    gradientFallback: 'from-amber-950 via-stone-900 to-slate-900',
  },
  meghalaya: {
    src: '/src/assets/images/dest_meghalaya_waterfalls_1795244387518.jpg',
    alt: 'Living root bridge and mist-draped waterfalls in Meghalaya, Northeast India',
    gradientFallback: 'from-emerald-950 via-slate-900 to-teal-950',
  },
  goa: {
    src: '/src/assets/images/dest_goa_konkan_1795244385608.jpg',
    alt: 'Palm-fringed South Goa cove with red laterite cliffs along the Konkan coast',
    gradientFallback: 'from-cyan-950 via-slate-900 to-amber-950',
  },
};
