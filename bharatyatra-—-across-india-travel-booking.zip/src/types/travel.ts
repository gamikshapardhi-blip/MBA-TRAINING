export type TravelCategory = 'packages' | 'flights_trains' | 'buses_cabs' | 'stays';

export type TransportMode =
  | 'Package'
  | 'Flight'
  | 'Vande Bharat'
  | 'Volvo Bus'
  | 'Intercity Cab'
  | 'Heritage Stay';

export type DepartureWindow = 'morning' | 'afternoon' | 'evening' | 'night';

export type ClassTier = 'Standard' | 'Comfort' | 'Executive';

export interface IndianHub {
  code: string;
  city: string;
  state: string;
  hubName: string;
  region: 'North' | 'South' | 'East' | 'West' | 'Northeast';
}

export interface ItineraryStep {
  dayOrStage: string;
  title: string;
  summary: string;
  location: string;
  highlight: string;
}

export interface TravelAddon {
  id: string;
  name: string;
  description: string;
  priceInr: number;
  perTraveler: boolean;
}

export type ImageKey =
  | 'hero'
  | 'kerala'
  | 'ladakh'
  | 'rajasthan'
  | 'meghalaya'
  | 'goa';

export interface TravelOffering {
  id: string;
  title: string;
  subtitle: string;
  category: TravelCategory;
  mode: TransportMode;
  originCode: string;
  originCity: string;
  destinationCode: string;
  destinationCity: string;
  region: 'North' | 'South' | 'East' | 'West' | 'Northeast';
  durationDays: number;
  durationMinutes: number;
  durationLabel: string;
  departureTime: string;
  arrivalTime: string;
  departureWindow: DepartureWindow;
  basePriceInr: number;
  rating: number;
  reviewCount: number;
  freeCancellation: boolean;
  cancellationPolicy: string;
  isFiveDayEscape: boolean;
  inclusions: string[];
  highlights: string[];
  imageKey: ImageKey;
  itinerary: ItineraryStep[];
  addons: TravelAddon[];
}

export interface SearchQuery {
  category: TravelCategory;
  origin: string;
  destination: string;
  departureDate: string;
  returnDate: string;
  travelers: number;
  classTier: ClassTier;
}

export interface QuoteBreakdown {
  offeringId: string;
  travelers: number;
  classTier: ClassTier;
  classMultiplier: number;
  baseFarePerPerson: number;
  baseSubtotal: number;
  addonsTotal: number;
  gstAmount: number;
  convenienceFee: number;
  promoCode: string | null;
  promoDiscount: number;
  promoMessage: string | null;
  grandTotal: number;
}

export interface TravelerInput {
  fullName: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
}

export type PaymentMethod = 'UPI' | 'Card' | 'NetBanking' | 'Wallet';

export interface CreateBookingPayload {
  offeringId: string;
  departureDate: string;
  returnDate: string;
  travelers: number;
  classTier: ClassTier;
  selectedAddonIds: string[];
  promoCode?: string;
  contactEmail: string;
  contactPhone: string;
  gstin?: string;
  travelerDetails: TravelerInput[];
  paymentMethod: PaymentMethod;
  paymentIdentifier: string;
}

export type BookingStatus = 'Upcoming' | 'Completed' | 'Cancelled';

export interface BookingRecord {
  pnrCode: string;
  offeringId: string;
  offeringTitle: string;
  mode: TransportMode;
  originCode: string;
  originCity: string;
  destinationCode: string;
  destinationCity: string;
  durationLabel: string;
  departureDate: string;
  returnDate: string;
  departureTime: string;
  travelers: number;
  classTier: ClassTier;
  selectedAddons: { id: string; name: string; priceInr: number }[];
  fare: QuoteBreakdown;
  contactEmail: string;
  contactPhone: string;
  gstin?: string;
  travelerDetails: TravelerInput[];
  paymentMethod: PaymentMethod;
  paymentLastFour: string;
  status: BookingStatus;
  createdAt: string;
  rescheduledFrom?: string;
  imageKey: ImageKey;
}

export interface UserSession {
  name: string;
  email: string;
  phone: string;
}
